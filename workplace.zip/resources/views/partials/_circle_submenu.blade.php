<a href="{{ route('staff.circles.general_room', ['circle'=>$circle->id]) }}" class="hover:underline">General Room</a>
<a href="{{ route('staff.circles.announcements', ['circle'=>$circle->id]) }}" class="hover:underline">Announcements</a>
<!--<div class="hover:underline">Projects</div> //-->
<!--<div class="hover:underline">Tasks</div> //-->
<a href="{{ route('staff.circles.team', ['circle'=>$circle->id]) }}" class="hover:underline">Staff</a>