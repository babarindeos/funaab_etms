@component("mail::message")
# Welcome to our Platform.

Dear {{ $name}},

There are a number of benefits to using our platform.


{{ url('/')}}
    
@endcomponent