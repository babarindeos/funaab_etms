<div>
    <!-- Well begun is half done. - Aristotle -->
</div>