<?php if(session('error')): ?>

            <?php if(session('status')=='success'): ?>
                <span class="flex flex-col w-[80%] md:w-[60%] py-4 px-2 my-2 bg-green-50 rounded text-green-800 font-medium" 
                        style="font-family:'Lato'; font-size:16px;"> 
                    <?php echo e(session('message')); ?>

                </span>
            <?php else: ?>
                <span class="flex flex-col w-[80%] md:w-[60%] py-4 px-2 my-2 bg-red-50 rounded text-red-800 font-medium" 
                        style="font-family:'Lato'; font-size:16px;">
                    <?php echo e(session('message')); ?>

                </span>
            <?php endif; ?>

<?php endif; ?><?php /**PATH C:\xampp\htdocs\goviflow\resources\views/partials/_session_response.blade.php ENDPATH**/ ?>