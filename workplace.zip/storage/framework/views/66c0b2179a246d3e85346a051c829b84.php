<br/>
<h2>Hi, <?php echo e($fullname); ?></h2>
An account has been created for you by the Administrator on Ogun State Government Workflow (GoviFlow). 
GoviFlow is the State Government's Platform for managing work processes across Ministries, Departments 
and Agencies (MDAs).
<br/><br/>
Please find below your username and password to access the application.

<br/></br/>
<b>username: </b><?php echo e($username); ?><br/>
<b>password: </b><?php echo e($password); ?>


<br/><br/>
You will be prompted to change your password at first login and also update your 
profile.

<br/><br/>
Thank you.
<?php /**PATH C:\xampp\htdocs\goviflow\resources\views\emails\onboarding.blade.php ENDPATH**/ ?>