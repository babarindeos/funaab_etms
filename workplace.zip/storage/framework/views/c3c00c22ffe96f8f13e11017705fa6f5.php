<?php if (isset($component)) { $__componentOriginald01fd79e7c9394df19aee57931ccf01c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald01fd79e7c9394df19aee57931ccf01c = $attributes; } ?>
<?php $component = App\View\Components\StaffLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('staff-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\StaffLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

<div class="flex flex-col container mx-4 border border-0 md:mx-auto">
    <section class="border-b border-gray-200 py-2 mt-2">
            <div class="text-2xl font-semibold ">
                Dashboard                
            </div>
            <div>
                <?php if(Auth::check()): ?>
                    Welcome <?php echo e(Auth::user()->surname); ?> <?php echo e(Auth::user()->firstname); ?>

                <?php endif; ?>
            </div>
    </section>

    <?php echo $__env->make('partials._document_submenu1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <div class="flex flex-col md:flex-row space-x-4">
        

        <?php if(count($workflow_notifications) > 0 ): ?>
        <div class="md:flex-1 border-0">
            <section class="py-8 mt-2">
                    <div class="text-lg font-semibold text-gray-600 border-b border-gray-200 ">
                        Workflow Notifications (<?php echo e($workflow_notifications->count()); ?>)
                    </div>
                    <div>
                        <ul class="list-disc px-10">
                            <?php $__currentLoopData = $workflow_notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="py-3 border-b border-gray-100">
                                    <a title="<?php echo e($notification->document->title); ?>" class="hover:underline" href="<?php echo e(route('staff.workflows.notification_update', ['workflow'=>$notification->id])); ?>" >
                                    
                                        <div class="font-medium text-gray-700">
                                            <?php echo e($notification->document->title); ?>

                                        </div>
                                        <div class="text-xs">
                                            from <?php echo e($notification->sender->surname); ?> @ 
                                            <?php echo e($notification->created_at->format('l jS F, Y g:i a')); ?>

                                        </div>
                                    </a>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                        <div class="py-2">
                                <?php echo e($workflow_notifications->links()); ?>

                        </div>

                    </div>
            </section>
        </div>
        <?php endif; ?>

        

        
        <?php if(count($private_message_notifications) > 0 ): ?>
        <div class="md:flex-1 border-0">
            <section class="py-8 mt-2">
                    <div class="text-lg font-semibold text-gray-600 border-b border-gray-200 ">
                        Message Notifications (<?php echo e($private_message_notifications->count()); ?>)
                    </div>
                    <div>
                        <ul class="list-disc px-10">
                            <?php $__currentLoopData = $private_message_notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="py-3 border-b border-gray-100">
                                    <a href="<?php echo e(route('staff.workflows.private_message.index', ['document'=>$notification->id, 'recipient'=>$notification->sender_id])); ?>" title="<?php echo e($notification->message); ?>" class="hover:underline"  >
                                    
                                        <div class="font-medium text-gray-700">
                                            <?php echo e($notification->message); ?>

                                        </div>
                                        <div class="text-xs">
                                            from <?php echo e($notification->sender->surname); ?> @ 
                                            <?php echo e($notification->created_at->format('l jS F, Y g:i a')); ?>

                                        </div>
                                    </a>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                        <div class="py-2">
                                <?php echo e($workflow_notifications->links()); ?>

                        </div>

                    </div>
            </section>
        </div>
        <?php endif; ?>



        <!-- recent workflows //-->
        <div class="md:flex-1 border-0">
                <div class="text-lg font-semibold text-gray-600 border-b border-gray-200 mt-10">
                    Recent Workflows
                </div>
                <div>
                    <ul class="list-disc  px-10">
                    <?php $__currentLoopData = $recent_workflows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $workflow): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($workflow->sender_id != Auth::user()->id): ?>
                                <li class="py-3 border-b border-gray-100">
                                    <a title="<?php echo e($workflow->document->title); ?>" class="hover:underline" href="<?php echo e(route('staff.workflows.flow', ['document'=>$workflow->document->id])); ?>" >
                                    
                                            <div class="font-medium text-gray-700">
                                            <?php echo e($workflow->document->title); ?>

                                            </div>
                                            <div class="text-xs">
                                                from <?php echo e($workflow->sender->surname); ?> @ 
                                                <?php echo e($workflow->created_at->format('l jS F, Y g:i a')); ?>

                                            </div>
                                    </a>
                                </li>
                            <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                    <div class="py-2">
                        <?php echo e($workflow_notifications->links()); ?>

                    </div>
                </div>

        </div>
        <!-- end of recent workflows //-->




        

    </div>


    
</div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald01fd79e7c9394df19aee57931ccf01c)): ?>
<?php $attributes = $__attributesOriginald01fd79e7c9394df19aee57931ccf01c; ?>
<?php unset($__attributesOriginald01fd79e7c9394df19aee57931ccf01c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald01fd79e7c9394df19aee57931ccf01c)): ?>
<?php $component = $__componentOriginald01fd79e7c9394df19aee57931ccf01c; ?>
<?php unset($__componentOriginald01fd79e7c9394df19aee57931ccf01c); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\goviflow\resources\views/staff/dashboard.blade.php ENDPATH**/ ?>