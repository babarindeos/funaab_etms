<?php if (isset($component)) { $__componentOriginald01fd79e7c9394df19aee57931ccf01c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald01fd79e7c9394df19aee57931ccf01c = $attributes; } ?>
<?php $component = App\View\Components\StaffLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('staff-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\StaffLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <div class="flex flex-col container mx-4 border border-0 md:mx-auto">
        <section class="border-b border-gray-200 py-2 mt-2">
                <div class="text-2xl font-semibold ">
                    Private Message              
                </div>
                
        </section>
    
        <section>
                <div class="flex flex-row space-x-4 md:space-x-8">
                        <div class="flex">
                                <a onclick="history.back();" class="border px-4 py-1 mt-1 cursor-pointer 
                                                                hover:font-semibold hover:border-gray-300">    
                                        &laquo; Back
                                </a>
                        </div>
                        <div class="flex md:justify-center items-center">
                                <a href="<?php echo e(route('staff.workflows.flow', ['document'=>$document->id])); ?>" class="font-semibold hover:underline cursor-pointer">
                                <?php echo e($document->title); ?>

                                </a>
                        </div>
                </div>
        </section>


        <section class="py-2 mt-2">
            
            <div class="flex md:w-[30%] text-xs justify-end">                                        
                <a href="<?php echo e(route('staff.workflows.general_message',['document'=>$document->id])); ?>" class="border border-1 rounded-md border-green-500 py-1 px-3
                        hover:bg-green-500 hover:text-white">
                        General Message
                </a>
            </div>
            
            <div class="flex flex-col md:flex-row border-1">
                                
                
                <div class="flex  md:w-[30%] border-0 px-2 py-2 overflow-y-auto h-100 mr-2"><!-- left panel //-->
                        
                    
                        
                        <!-- Workflow Contributors //-->
                        <div class="w-full mt-2">
                            <?php $__currentLoopData = $workflow_contributors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contributor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="w-full py-1">
                                        <div class="flex flex-row w-full text-sm border-b ">
                                                <div class="flex flex-col justify-center px-2 py-2 items-center">
                                                        <img class="w-12" src="<?php echo e(asset('images/avatar_64.jpg')); ?>" />                                                                
                                                </div>
                                                <div class="flex flex-col py-2 w-full">
                                                    <div class="font-bold"><?php echo e($contributor->user->staff->surname); ?>  <?php echo e($contributor->user->staff->firstname); ?></div>
                                                    <div><?php echo e($contributor->user->staff->department->department_name); ?>  (<?php echo e($contributor->user->staff->department->department_code); ?>)</div>
                                                    <div><?php echo e($contributor->user->staff->department->ministry->name); ?> (<?php echo e($contributor->user->staff->department->ministry->code); ?>)</div>
                                                    
                                                </div>
                                        </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <!-- end of workflow contributors //-->


                </div><!-- end of left pane //-->


                <div class="flex flex-col md:border-l  md:w-[60%] px-3 py-0 mb-2"><!-- Right pane //-->
                    <form action="<?php echo e(route('staff.workflows.private_message.store',['document'=>$document->id, 'sender'=>$sender, 
                                                                                   'recipient'=>$recipient, 'chat_uuid'=>$chat_uuid])); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <!-- textarea //-->
                            <div>
                                    <span class="text-sm">
                                        @ <?php echo e($recipient->surname); ?> <?php echo e($recipient->firstname); ?>

                                    </span>
                            </div>
                            <div class="flex items-center py-1">
                                    <textarea name="message" rows="3" class="overflow-hidden border border-1 border-gray-400 bg-gray-50
                                            w-full p-1 py-2 rounded-md 
                                            focus:outline-none
                                            focus:border-blue-500 
                                            focus:ring
                                            focus:ring-blue-100" 
                                            
                                            value="<?php echo e(old('message')); ?>"
                                            
                                            style="font-family:'Lato';font-size:16px;font-weight:500;"                                                                     
                                            maxlength="140">  </textarea>
                            </div>
                            <!-- end of textarea //-->

                            <!-- button //-->
                            <div class="flex justify-between">

                                <div class="flex text-xs text-gray-500">
                                    140 characters max
                                </div>
                                
                                <div>    
                                    <button type="submit" class="border border-1 border-green-500
                                    bg-green-500 text-white rounded-md py-2 px-4 text-xs font-semibold">
                                            Send
                                    </button>
                                </div>
                            </div>
                            <!-- end of button //-->
                    </form>



                    <!-- list of messages //-->
                    <div class="flex flex-col border-0 border-blue-900 h-50 overflow-y-auto py-2 mt-2">
                            
                        <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="flex flex-row my-2">
                                    <div class="px-3 border-0">
                                            <img class="w-12" src="<?php echo e(asset('images/avatar_64.jpg')); ?>" />  
                                    </div>
                                    <div class="px-3 py-1 rounded-md bg-gray-100 w-full">
                                            <div class="font-semibold text-sm">
                                                    <?php echo e($message->sender->surname); ?> <?php echo e($message->sender->firstname); ?>

                                            </div>
                                            <div class="text-xs">
                                                    <?php echo e($message->created_at->format('l jS F, Y @ g:i a')); ?>

                                            </div>
                                            <div class="text-sm py-2">
                                                    <?php echo e($message->message); ?>

                                            </div>

                                    </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
                    <!-- end of list of messages //-->
                                                                                

                </div><!-- end of right panel //-->
            </div>             
        </section>
        
    </div>
    
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald01fd79e7c9394df19aee57931ccf01c)): ?>
<?php $attributes = $__attributesOriginald01fd79e7c9394df19aee57931ccf01c; ?>
<?php unset($__attributesOriginald01fd79e7c9394df19aee57931ccf01c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald01fd79e7c9394df19aee57931ccf01c)): ?>
<?php $component = $__componentOriginald01fd79e7c9394df19aee57931ccf01c; ?>
<?php unset($__componentOriginald01fd79e7c9394df19aee57931ccf01c); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\goviflow\resources\views\staff\private_messages\chat.blade.php ENDPATH**/ ?>