<?php if (isset($component)) { $__componentOriginal69dc84650370d1d4dc1b42d016d7226b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal69dc84650370d1d4dc1b42d016d7226b = $attributes; } ?>
<?php $component = App\View\Components\GuestLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\GuestLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <div class="flex flex-col w-4/5  md:w-1/3 mx-auto items-center justify-center rounded-md mt-8 mb-8 ">
        <form name="profile_create" action="<?php echo e(route('staff.profile.store')); ?>" method="POST"  enctype="multipart/form-data" 
                class="flex flex-col border border-1 justify-center items-center w-full rounded-md shadow-md py-16">
            <?php echo csrf_field(); ?>
            <div class="flex flex-col py-2 justify-center items-center font-semibold text-xl">
                    Create Profile
            </div>
            <div class="flex flex-row justify-center">
                    
                    <?php if($profile==null): ?>
                        <img src="<?php echo e(asset('images/avatar_150.jpg')); ?>" class="w-150" />
                    <?php else: ?>
                        <img src="<?php echo e(asset('storage/'.$profile->avatar)); ?>" class="w-36 h-36 rounded-full" />
                    <?php endif; ?>
                    
            </div>
            
            <!-- file upload //-->
            <div class="flex flex-col border-red-900 w-[80%] md:w-[60%] py-1">
                                
                                
                <input type="file" name="avatar" id="avatar" class="border border-1 border-gray-400 bg-gray-50
                                                         w-full p-3 rounded-md 
                                                         focus:outline-none
                                                         focus:border-blue-500 
                                                         focus:ring
                                                         focus:ring-blue-100" 
                  
                 style="font-family:'Lato';font-size:16px;font-weight:500;"
                 accept=".jpg, .jpeg, .png"
                 required
                 />
                    

                 <?php $__errorArgs = ['avatar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-red-700 text-sm">
                        <?php echo e($message); ?>

                    </span>
                 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                
            </div>
           <!-- end of file upload //-->


            <!-- designation  //-->
            <div class="flex flex-col border-red-900 w-[80%] md:w-[60%] py-1">
                                    
                                    
                <input type="text" name="designation" placeholder="Designation" class="border border-1 border-gray-400 bg-gray-50
                                                        w-full p-3 rounded-md 
                                                        focus:outline-none
                                                        focus:border-blue-500 
                                                        focus:ring
                                                        focus:ring-blue-100" 
                <?php if($profile!=null): ?>  value="<?php echo e($profile->designation); ?> " <?php endif; ?>
                style="font-family:'Lato';font-size:16px;font-weight:500;"   
                required          
                 />
                    

                <?php $__errorArgs = ['designation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-red-700 text-sm">
                        <?php echo e($message); ?>

                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                
            </div>
            <!-- end of designation //-->


            <!-- phone  //-->
            <div class="flex flex-col border-red-900 w-[80%] md:w-[60%] py-1">
                                    
                                    
                <input type="text" name="phone" placeholder="Phone Number" class="border border-1 border-gray-400 bg-gray-50
                                                        w-full p-3 rounded-md 
                                                        focus:outline-none
                                                        focus:border-blue-500 
                                                        focus:ring
                                                        focus:ring-blue-100" 
                <?php if($profile!=null): ?> value="<?php echo e($profile->phone); ?>" <?php endif; ?>
                style="font-family:'Lato';font-size:16px;font-weight:500;"             
                required/>
                    

                <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-red-700 text-sm">
                        <?php echo e($message); ?>

                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                
            </div>
            <!-- end of phone //-->


            <!-- button //-->
            <div class="flex flex-row border-red-900 w-[80%] md:w-[60%] py-2 mb-2 space-x-2">
                <div class="flex flex-1 w-full border border-1">
                    <button type="submit" class="w-full border border-1 bg-gray-400 py-4 text-white 
                                hover:bg-gray-500 
                                focus:outline-none
                                focus:border-gray-200
                                focus:ring
                                focus:ring-gray-200
                                rounded-md text-md" style="font-family:'Lato';font-weight:500;">Create Profile</button>
                </div>
                
                <?php if($profile!=null): ?>
                    <div class="flex border border-1">
                            <a href="<?php echo e(route('staff.dashboard.index')); ?>" class="w-full border border-1 bg-green-400 py-4 px-4 text-white 
                                 hover:bg-green-500 rounded-md text-md" style="font-family:'Lato';font-weight:500;">Continue</a>
                    </div>
                <?php endif; ?>
            </div>



        <!-- end of buttons //-->



        </form>


    </div>


 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal69dc84650370d1d4dc1b42d016d7226b)): ?>
<?php $attributes = $__attributesOriginal69dc84650370d1d4dc1b42d016d7226b; ?>
<?php unset($__attributesOriginal69dc84650370d1d4dc1b42d016d7226b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b)): ?>
<?php $component = $__componentOriginal69dc84650370d1d4dc1b42d016d7226b; ?>
<?php unset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b); ?>
<?php endif; ?>

<?php /**PATH C:\xampp\htdocs\funaab\workplace\resources\views/staff/profile/create.blade.php ENDPATH**/ ?>