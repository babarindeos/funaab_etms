<?php if (isset($component)) { $__componentOriginal69dc84650370d1d4dc1b42d016d7226b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal69dc84650370d1d4dc1b42d016d7226b = $attributes; } ?>
<?php $component = App\View\Components\GuestLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\GuestLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <section class="flex border border-0 border-red-900 w-full">
        
            <!-- left side //-->
            <div class="hidden md:flex w-1/5 bg-green-100" 
                style="background-image:url('<?php echo e(asset('images/goviflow_low.jpg')); ?>'); 
                background-size: cover; 
                background-repeat: repeat
                background-position: right; background-color:#f1f1f1;"
            >
                
            </div>
            <!-- end of left side //-->

            <!-- second side //-->
            <div class="flex flex-col justify-center w-4/5 max-w-4xl mx-auto">
                
                <div class="border border-0">
                    <form  action="<?php echo e(route('admin.auth.login')); ?>" method="POST" class="flex flex-col mx-auto w-[80%] items-center justify-center md:items-start">
                        <?php echo csrf_field(); ?>

                        <div class="flex flex-col w-[80%] md:w-[60%] py-4 mt-4 font-serif" >
                            <h2 class="font-semibold text-xl py-1" >Sign In</h2>
                            Administrators Only 
                            
                        </div>

                        

                        <!-- Session Status -->
                        <?php if(session('error')): ?>

                                    <?php if(session('status')=='success'): ?>
                                        <span class="flex flex-col w-[80%] md:w-[60%] py-4 px-2 my-2 bg-green-50 rounded text-green-800 font-medium" 
                                                style="font-family:'Lato'; font-size:16px;"> 
                                            <?php echo e(session('message')); ?>

                                        </span>
                                    <?php else: ?>
                                        <span class="flex flex-col w-[80%] md:w-[60%] py-4 px-2 my-2 bg-red-50 rounded text-red-800 font-medium" 
                                                style="font-family:'Lato'; font-size:16px;">
                                            <?php echo e(session('message')); ?>

                                        </span>
                                    <?php endif; ?>

                        <?php endif; ?>
                        


                        <!-- EMail //-->
                        <div class="flex flex-col border-red-900 w-[80%] md:w-[60%] py-3">
                            <!--<label for="email" class="font-semibold text-gray-700">Email</label> //-->
                            
                            <input type="text" name="email" class="border border-1 border-gray-400 bg-gray-50
                                                                    w-full p-4 rounded-md 
                                                                    focus:outline-none
                                                                    focus:border-blue-500 
                                                                    focus:ring
                                                                    focus:ring-blue-100" placeholder="Email"
                                                                    
                                                                    style="font-family:'Lato';font-size:16px;font-weight:500;"
                                                                    
                                                                    value="<?php echo e(old('email')); ?>"
                                                                    />                                                                         

                                                                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                        <span class="text-red-700 text-sm">
                                                                            <?php echo e($message); ?>

                                                                        </span>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            
                        </div>
                        <!-- end of Email //-->


                         <!-- Password //-->
                         <div class="flex flex-col border-red-900 w-[80%] md:w-[60%] py-3">
                            <!--<label for="password" class="font-semibold text-gray-700">Password</label> //-->
                            
                            <input type="password" name="password" class="border border-1 border-gray-400 bg-gray-50
                                                                    w-full p-4 rounded-md 
                                                                    focus:outline-none
                                                                    focus:border-blue-500 
                                                                    focus:ring
                                                                    focus:ring-blue-100" placeholder="Password"
                                                                    
                                                                    style="font-family:'Lato';font-size:16px;font-weight:500;"
                                                                    
                                                                    
                                                                    />                                                                         

                                                                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                        <span class="text-red-700 text-sm">
                                                                            <?php echo e($message); ?>

                                                                        </span>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            
                        </div>
                        <!-- end of Password //-->

                        <!-- submit button //-->
                        <div class="flex flex-col border-red-900 w-[80%] md:w-[60%] py-2">
                            <button type="submit" class="border border-1 bg-gray-400 py-4 text-white 
                                        hover:bg-gray-500
                                        rounded-md text-lg" style="font-family:'Lato';font-weight:500;">Sign In</button>
                        </div>



                    </form>
                </div>
            </div>
            <!-- end of second side //-->

    </section>



 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal69dc84650370d1d4dc1b42d016d7226b)): ?>
<?php $attributes = $__attributesOriginal69dc84650370d1d4dc1b42d016d7226b; ?>
<?php unset($__attributesOriginal69dc84650370d1d4dc1b42d016d7226b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b)): ?>
<?php $component = $__componentOriginal69dc84650370d1d4dc1b42d016d7226b; ?>
<?php unset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\goviflow\resources\views/admin/auth/login.blade.php ENDPATH**/ ?>