<?php if (isset($component)) { $__componentOriginald01fd79e7c9394df19aee57931ccf01c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald01fd79e7c9394df19aee57931ccf01c = $attributes; } ?>
<?php $component = App\View\Components\StaffLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('staff-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\StaffLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <div class="flex flex-col container mx-4 border border-0 md:mx-auto">
        <section class="border-b border-gray-200 py-2 mt-2">
                <div class="text-2xl font-semibold ">
                    Circles               
                </div>
                
        </section>

        <!-- section //-->
        <section class="py-4 border-0">

            <!-- navigation //-->
            <div class="flex flex-col md:flex-row space-y-4 md:space-y-0 md:justify-between md:items-center border-0 ">
                    <div>
                        <div class="text-xl text-gray-800 font-semibold">
                            <?php echo e($circle->cell->name); ?> (<?php echo e($circle->cell->code); ?>)
                        </div>
                        <div class="text-gray-600 font-medium text-lg">
                            Team
                        </div>

                        

                    </div>
                    <div class="flex flex-row space-x-4">
                            <?php echo $__env->make('partials._circle_submenu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
            </div>
            <!-- end of navigation //-->
            
        </section>
        <!-- section //-->


        <!-- Team Section  //-->
        <!-- section //-->
        <section class="py-4 border-0">
            <div class="flex flex-col md:flex-row md:flex-wrap w-full mx-auto justify-center gap-4">
                <?php $__currentLoopData = $circle->cell->users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                    <!-- Team member //-->
                    <div class="flex flex-col items-center p-8 border rounded-md shadow-lg w-full md:w-[calc(33%-1rem)]">
                        <div>
                            <?php if($team->user->profile != null && $team->user->profile->avatar != ''): ?>
                                <img src="<?php echo e(asset('storage/'.$team->user->profile->avatar)); ?>" class="w-36 h-36 rounded-full" />
                            <?php else: ?>
                                <!-- Placeholder or alternate content -->
                                <img src="<?php echo e(asset('images/avatar.jpg')); ?>" class="w-36 h-36" />
                            <?php endif; ?>
                        </div>
                        <div class="p-2 text-lg font-medium text-center">
                            <a href="<?php echo e(route('staff.profile.email_user_profile', ['email' => $team->user->email])); ?>" class="hover:underline">
                                <?php 
                                    $surname = ucfirst(strtolower($team->user->surname))
                                ?>
                                <?php echo e($surname); ?> <?php echo e($team->user->firstname); ?>

                            </a>
                            <div class="text-sm">
                                <?php echo e($team->user->profile->designation); ?><br /><?php echo e($team->role); ?>

                            </div>
                        </div>
                    </div>
                    <!-- end of team member //-->                   

                    

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </section>
        
        <!-- section //-->
    


        <!-- End of Team Section //-->

     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald01fd79e7c9394df19aee57931ccf01c)): ?>
<?php $attributes = $__attributesOriginald01fd79e7c9394df19aee57931ccf01c; ?>
<?php unset($__attributesOriginald01fd79e7c9394df19aee57931ccf01c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald01fd79e7c9394df19aee57931ccf01c)): ?>
<?php $component = $__componentOriginald01fd79e7c9394df19aee57931ccf01c; ?>
<?php unset($__componentOriginald01fd79e7c9394df19aee57931ccf01c); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\funaab\workplace\resources\views/staff/circles/team.blade.php ENDPATH**/ ?>