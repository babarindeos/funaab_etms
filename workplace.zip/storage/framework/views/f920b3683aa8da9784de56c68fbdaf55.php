<?php if (isset($component)) { $__componentOriginald01fd79e7c9394df19aee57931ccf01c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald01fd79e7c9394df19aee57931ccf01c = $attributes; } ?>
<?php $component = App\View\Components\StaffLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('staff-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\StaffLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <div class="flex flex-col container mx-4 border border-0 md:mx-auto">
        <section class="border-b border-gray-200 py-2 mt-2">
                <div class="text-2xl font-semibold ">
                    Documents               
                </div>
                
        </section>
    
        <?php echo $__env->make('partials._document_submenu1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


        <section class="py-8 mt-2">

            <div class="flex flex-col md:flex-row w-full space-y-4 md:space-y-0 md:space-x-4 ">
                    <!-- left panel //-->
                    <div class="flex flex-col w-full md:w-3/5 border border-1 rounded-md py-2 px-4">
                            <div class="border-b border-1 py-2">
                                    <div class="font-semibold">
                                        <?php echo e($document->title); ?>

                                    </div>
                                    <div class="flex flex-col md:flex-row border border-0 justify-between md:items-center ">

                                        <div class="text-xs">
                                            <?php
                                                $surname = ucfirst(strtolower($document->staff->surname))
                                            ?>

                                            Submitted by <?php echo e($surname); ?> <?php echo e($document->staff->firstname); ?> @ <?php echo e($document->created_at->format('l jS F, Y  g:i a')); ?>

                                        </div>

                                        <div class="flex flex-row space-x-4 border border-0">
                                                <div class="text-sm underline">Edit</div>
                                                <div class="text-sm underline">Delete</div>
                                        </div>
                                        
                                    </div>
                            </div>
                            <div class="flex flex-row text-sm py-8 justify-content items-center">
                                        <a href="<?php echo e(asset('storage/'.$document->document)); ?>" target="_blank" 
                                                class="px-6 py-6 text-center border border-1 hover:bg-blue-100 
                                                    rounded-md hover:border-blue-100 justify-center">
                                                <div class="flex justify-center">
                                                        <?php if($document->filetype == "MS Word"): ?>
                                                        <img src="<?php echo e(asset('images/icon_doc_50.jpg')); ?>"  />
                                                        <?php elseif($document->filetype == "PDF"): ?>
                                                        <img src="<?php echo e(asset('images/icon_pdf_50.jpg')); ?>" />
                                                        <?php elseif($document->filetype == "Image | jpg"): ?>
                                                        <img src="<?php echo e(asset('images/icon_image_50.jpg')); ?>"/>
                                                        <?php elseif($document->filetype == "Image | jpeg"): ?>
                                                        <img src="<?php echo e(asset('images/icon_image_50.jpg')); ?>"/>
                                                        <?php elseif($document->filetype == "Image | png"): ?>
                                                        <img src="<?php echo e(asset('images/icon_image_50.jpg')); ?>"/>
                                                        <?php endif; ?>
                                                </div>

                                                <div class="">
                                                        <?php echo e($document->filetype); ?>

                                                </div>
                                                <div class="text-xs">
                                                        <?php echo e($document->filesize); ?>

                                                </div>
                                        </a>
                                        <div class="px-4 py-2">
                                                <?php if($document->comment==''): ?>
                                                    No Comment

                                                <?php else: ?>
                                                    <?php echo e($document->comment); ?>

                                                <?php endif; ?> 

                                                <!-- workflow start or continue //-->
                                                <div class="py-4">
                                                        <?php if($workflowCount == 0): ?>
                                                                <span class="border border-1 
                                                                               py-1 px-4 text-sm rounded-md
                                                                               bg-green-500 text-white border-green-500">
                                                                        <a href="<?php echo e(route('staff.workflows.flow', ["document"=>$document->id])); ?>">
                                                                                Start Workflow
                                                                        </a>
                                                                    
                                                                </span>
                                                        <?php else: ?>
                                                                <span class="border border-1 
                                                                                py-1 px-4 text-sm rounded-md
                                                                                bg-green-500 text-white border-green-500">
                                                                        <a href="<?php echo e(route('staff.workflows.flow', ["document"=>$document->id])); ?>">
                                                                                Workflow
                                                                        </a>
                                                                
                                                                </span>
                                                        <?php endif; ?>
                                                </div>
                                        </div>
                            </div>

                    </div>
                    <!-- end of left panel //-->

                    <!-- right panel //-->
                    <div class="w-full md:w-2/5 md:flex-grow border border-1 py-4 px-4 rounded-md">
                            <div class="font-semibold text-gray-500">
                                    Workflow Contributors
                            </div>

                            <div class="w-full mt-2">
                                <?php $__currentLoopData = $workflow_contributors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contributor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="w-full py-1">
                                            <div class="flex flex-row w-full text-sm border-b ">
                                                    <div class="flex flex-col justify-center px-4 py-2 items-center">
                                                                                                                       
                                                            <?php if($contributor->user->profile!=null && $contributor->user->profile->avatar!="" ): ?>
                                                                            
                                                                            <img src="<?php echo e(asset('storage/'.$contributor->user->profile->avatar)); ?>" class='w-12 h-10 rounded-full' />
                                                                        
                                                            <?php else: ?>
                                                                            <img class="w-12" src="<?php echo e(asset('images/avatar_64.jpg')); ?>" />  
                                                            <?php endif; ?>
                                                    </div>
                                                    <div class="flex flex-col py-2 w-full">
                                                        <a href="<?php echo e(route('staff.profile.email_user_profile', ['email'=>$contributor->user->email])); ?>" class="font-bold hover:underline">
                                                                
                                                                <?php
                                                                        $surname = ucfirst(strtolower($contributor->user->staff->surname))
                                                                ?>

                                                                <?php echo e($surname); ?>  <?php echo e($contributor->user->staff->firstname); ?>

                                                        </a>
                                                        <div>
                                                                 <?php if($contributor->user->profile != null && $contributor->user->profile->designation != "" ): ?>
                                                                        <?php echo e($contributor->user->profile->designation); ?> 
                                                                 <?php endif; ?>
                                                        </div>
                                                        
                                                        
                                                    </div>
                                            </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                    </div>
                    <!-- end of right panel //-->
            </div>
             
        </section>
        
    </div>
    
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald01fd79e7c9394df19aee57931ccf01c)): ?>
<?php $attributes = $__attributesOriginald01fd79e7c9394df19aee57931ccf01c; ?>
<?php unset($__attributesOriginald01fd79e7c9394df19aee57931ccf01c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald01fd79e7c9394df19aee57931ccf01c)): ?>
<?php $component = $__componentOriginald01fd79e7c9394df19aee57931ccf01c; ?>
<?php unset($__componentOriginald01fd79e7c9394df19aee57931ccf01c); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\funaab\workplace\resources\views/staff/documents/show.blade.php ENDPATH**/ ?>