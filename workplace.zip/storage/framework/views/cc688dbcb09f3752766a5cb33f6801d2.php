<div>
    <!-- Well begun is half done. - Aristotle -->
</div><?php /**PATH C:\xampp\htdocs\goviflow\resources\views\components\layouts\admin-layout.blade.php ENDPATH**/ ?>