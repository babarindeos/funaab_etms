<?php if (isset($component)) { $__componentOriginal91fdd17964e43374ae18c674f95cdaa3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal91fdd17964e43374ae18c674f95cdaa3 = $attributes; } ?>
<?php $component = App\View\Components\AdminLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AdminLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="container">
        <!-- page header //-->
        <section class="flex flex-col w-[95%] md:w-[95%] py-2 mt-6 px-4 border-red-900 mx-auto">
        
            <div class="flex border-b border-gray-300 py-2 justify-between">
                    <div >
                        <h1 class="text-2xl font-semibold font-serif text-gray-800">Ministry</h1>
                        <div><?php echo e($ministry->name); ?> (<?php echo e($ministry->code); ?>)</div>
                    </div>
                    
            </div>
        </section>
        <!-- end of page header //-->
    


        <section class="flex flex-col md:flex-row w-[95%] md:w-[95%] py-2 mt-6 px-4 mx-auto">
            

            <!-- Departments //-->
            <div class="flex flex-col flex-1 border border-0">
                    <div class="flex justify-between border border-0 py-1">
                        <div class="flex flex-row justify-start items-center">
                             <span class="text-lg font-semibold">Departments (<?php echo e($departments->count()); ?>) </span>
                        </div>
                        <input type="text" name="search" class="w-3/5 md:w-3/5 border border-1 border-gray-400 bg-gray-50
                                    p-2 rounded-md 
                                    focus:outline-none
                                    focus:border-blue-500 
                                    focus:ring
                                    focus:ring-blue-100" placeholder="Search"                
                                
                                    style="font-family:'Lato';font-size:16px;font-weight:500;"                                                                  
                        
                        />  
                    </div>

                    <table  class="table-auto border-collapse border border-1 border-gray-200 w-full">
                        <thead>
                            <tr class="border-b-1 border border-1 border-gray-200" >
                                <th class="py-1">SN</th>
                                <th class="text-left">Departments</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                $counter = 0;
                            ?>
                            <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="border-b-1 border-gray-200">
                                    <td class="text-center py-1"><?php echo e(++$counter); ?>.</td>
                                    <td><?php echo e($department->department_name); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                            
                        </tbody>
                    </table>

                    <div>
                        <?php echo e($departments->links()); ?>

                    </div>

            </div>
            <!-- end of departments //-->

            <!-- Users //-->
            <div class="flex flex-1">

            </div>
            <!-- end of User //-->

        </section>

    </div><!-- end of container //-->


 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $attributes = $__attributesOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__attributesOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $component = $__componentOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\goviflow\resources\views/admin/ministries/show.blade.php ENDPATH**/ ?>