<?php if (isset($component)) { $__componentOriginald01fd79e7c9394df19aee57931ccf01c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald01fd79e7c9394df19aee57931ccf01c = $attributes; } ?>
<?php $component = App\View\Components\StaffLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('staff-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\StaffLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <div class="flex flex-col container mx-4 border border-0 md:mx-auto">
        <section class="border-b border-gray-200 py-2 mt-2">
                <div class="text-2xl font-semibold ">
                    Workflow - Add Contributor          
                </div>
                
        </section>
    
        <?php echo $__env->make('partials._document_submenu1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


        <section class="py-8 mt-2">

            <div class="flex flex-col md:flex-row w-full space-y-4 md:space-y-0 md:space-x-4 ">
                    <!-- left panel //-->
                    <div class="flex flex-col w-full md:w-3/5 border border-1 rounded-md py-2 px-4">
                            <div class="border-b border-1 py-2">
                                    <div class="font-semibold">
                                        <?php echo e($document->title); ?>

                                    </div>
                                    <div class="flex flex-col md:flex-row border border-0 justify-between md:items-center ">

                                        <div class="text-xs">
                                            Submitted by <?php echo e($document->staff->surname); ?> <?php echo e($document->staff->firstname); ?> @ <?php echo e($document->created_at->format('l jS F, Y  g:i a')); ?>

                                        </div>

                                       
                                        
                                    </div>
                            </div>
                            <div class="flex flex-row text-sm py-4 justify-content items-start">
                                        <div class="flex flex-col w-1/5">
                                                <a href="<?php echo e(asset('storage/'.$document->document)); ?>" target="_blank" 
                                                        class="px-6 py-6 text-center border border-1 hover:bg-blue-100 
                                                            rounded-md hover:border-blue-100 justify-center">
                                                        <div class="flex justify-center">
                                                                <?php if($document->filetype == "MS Word"): ?>
                                                                <img src="<?php echo e(asset('images/icon_doc_50.jpg')); ?>"  />
                                                                <?php elseif($document->filetype == "PDF"): ?>
                                                                <img src="<?php echo e(asset('images/icon_pdf_50.jpg')); ?>" />
                                                                <?php elseif($document->filetype == "Image | jpg"): ?>
                                                                <img src="<?php echo e(asset('images/icon_image_50.jpg')); ?>"/>
                                                                <?php endif; ?>
                                                        </div>

                                                        <div class="">
                                                                <?php echo e($document->filetype); ?>

                                                        </div>
                                                        <div class="text-xs">
                                                                <?php echo e($document->filesize); ?>

                                                        </div>
                                                </a>
                                        </div>
                                        <div class="px-4 py-2 border border-0 w-full">
                                               

                                                <!-- workflow start or continue //-->
                                                <div class="flex flex-col md:flex-row py-4">

                                                    <!-- forward to contributor //-->
                                                    <div class="flex flex-col flex-1">
                                                            <div class="font-semibold py-2 text-base text-gray-600">Add a contributor to this document</div>

                                                            <form action="<?php echo e(route('staff.workflows.search_staff', ['document'=>$document->id])); ?>" method="post">
                                                                <?php echo csrf_field(); ?>

                                                                <!-- Contributor panel //-->
                                                                <div class="flex flex-col md:flex-row w-full border border-0">
                                                                    <!-- Select List to Contributors //-->
                                                                    <div class="flex flex-col border-red-900 w-[97%] md:w-[70%] py-2 mr-4">
                                                                            
                                                                            
                                                                            <input type="text" name="staffno" class="border border-1 border-gray-400 bg-gray-50
                                                                                                                    w-[90%] p-1 rounded-md 
                                                                                                                    focus:outline-none
                                                                                                                    focus:border-blue-500 
                                                                                                                    focus:ring
                                                                                                                    focus:ring-blue-100"                                                                                                                                                                                                                                                                                                                                                
                                                                                                                    placeholder="Enter Staff No."

                                                                                                                    style="font-family:'Lato';font-size:16px;font-weight:500;"
                                                                                                                    required
                                                                                                                    />
                                                                                                                    
                                                                                                                                                                                            
                                                                            

                                                                            <?php $__errorArgs = ['staffno'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                                <span class="text-red-700 text-sm">
                                                                                    <?php echo e($message); ?>

                                                                                </span>
                                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                        
                                                                    </div>                                                                
                                                                    <!-- end of List of Contributors //-->

                                                                    <!-- search button //-->
                                                                    <div class="flex border border-0 md:justify-center md:items-center">
                                                                        <button type="submit" class="border border-1
                                                                            rounded-md py-2 px-4 text-xs text-green-500 border-green-500 hover:bg-green-500 hover:text-white font-semibold">
                                                                            Search
                                                                        </button>
                                                                    </div>
                                                                    <!-- end of search button //-->

                                                                </div>                                                            
                                                                <!-- end of contributor panel //-->
                                                            </form>


                                                            



                                                                <!-- submit button //-->
                                                                <div class="flex py-6">
                                                                    <?php if(session('error')): ?>
                                                                        <?php if(session('status')=='fail'): ?>
                                                                                <span class="flex flex-col w-[80%] md:w-[60%] py-4 px-2 my-2 bg-red-50 rounded text-red-800 font-medium" 
                                                                                    style="font-family:'Lato'; font-size:16px;"> 
                                                                                    <div class="font-semibold text-xs mb-1">[Process Error]</div>
                                                                                    <?php echo e(session('message')); ?>

                                                                                </span>
                                                                        <?php endif; ?>

                                                                    <?php else: ?>
                                                                        <?php if(session('status')=='success' && session('staff')): ?>
                                                                            <?php
                                                                                $staff = session('staff');
                                                                            ?>
                                                                            <div class="flex flex-col border border-1 w-full py-4 px-4">
                                                                                    <div class="flex flex-row">
                                                                                            <div class="py-2 px-4">
                                                                                                    <div class="rounded-full w-50 h-50 bg-gray-200">
                                                                                                        <?php if($staff->profile!=null && $staff->profile->avatar!="" ): ?>
                                                                            
                                                                                                        <img src="<?php echo e(asset('storage/'.$staff->profile->avatar)); ?>" class='w-12 h-10 rounded-full' />
                                                                                                    
                                                                                                        <?php else: ?>
                                                                                                            <img class="w-12" src="<?php echo e(asset('images/avatar_64.jpg')); ?>" />  
                                                                                                        <?php endif; ?>
                                                                                                   
                                                                                                    </div>
                                                                                            </div>
                                                                                            <div>
                                                                                                    <div>
                                                                                                            <div class='font-semibold'><?php echo e($staff->title); ?> <?php echo e($staff->surname); ?> <?php echo e($staff->firstname); ?>, <?php echo e($staff->fileno); ?></div>
                                                                                                            <div><?php echo e($staff->department->department_name); ?></div>
                                                                                                            <div><?php echo e($staff->department->ministry->name); ?></div>
                                                                                                    </div>

                                                                                                    <form action="<?php echo e(route('staff.workflows.post_add_contributor',['document'=>$document->id])); ?>" method="POST">
                                                                                                        <?php echo csrf_field(); ?>
                                                                                                        <div class="mt-2">
                                                                                                            <input type="hidden" name='user_id' value="<?php echo e($staff->user_id); ?>" />
                                                                                                            <button type="submit" class="border border-1 border-green-500
                                                                                                            bg-green-500 text-white rounded-md py-2 px-4 text-xs font-semibold">
                                                                                                                Add as Contributor
                                                                                                            </button>
                                                                                                        </div>
                                                                                                    </form>
                                                                                            </div>

                                                                                    </div>

                                                                                    
                                                                            </div>

                                                                        <?php endif; ?>
                                                                    
                                                                            
                                                                                                                                                   
                                                                                
                                                                           
                                                                    <?php endif; ?>
                                                                </div>
                                                                <!-- end of submit button //-->



                                                            
                                                            <!-- end of forward button //-->



                                                    </div>
                                                    <!-- end of forward to contributor //-->

                                                    <!-- Add contributor //-->
                                                    <div class="flex flex-col justify-center border border-0 md:items-center md:px-2 py-2 ">
                                                                
                                                               

                                                    </div>
                                                    <!-- end of Add contributor //-->

                                                    

                                                        
                                                </div>
                                        </div>
                            </div>

                    </div>
                    <!-- end of left panel //-->

                    <!-- right panel //-->
                    <div class="w-full md:w-2/5 md:flex-grow border border-1 py-4 px-4 rounded-md">
                            <div class="font-semibold text-gray-500 mb-2" >
                                    Workflow Contributors
                            </div>

                            <div class="w-full ">
                                    <?php $__currentLoopData = $workflow_contributors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contributor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="w-full ">
                                                <div class="flex flex-row w-full text-sm border-b ">
                                                        <div class="flex flex-col justify-center px-2 py-2 items-center">
                                                                
                                                                <?php if($contributor->user->profile!=null && $contributor->user->profile->avatar!="" ): ?>
                                                                            
                                                                    <img src="<?php echo e(asset('storage/'.$contributor->user->profile->avatar)); ?>" class='w-12 h-10 rounded-full' />
                                                            
                                                                <?php else: ?>
                                                                    <img class="w-12" src="<?php echo e(asset('images/avatar_64.jpg')); ?>" />  
                                                                <?php endif; ?>                                                         
                                                        </div>
                                                        <div class="flex flex-col py-2 w-full">
                                                            <div class="font-bold"><?php echo e($contributor->user->staff->surname); ?>  <?php echo e($contributor->user->staff->firstname); ?></div>
                                                            <div><?php echo e($contributor->user->staff->department->department_name); ?>  <?php echo e($contributor->user->staff->department->department_code); ?></div>
                                                            <div><?php echo e($contributor->user->staff->department->ministry->name); ?></div>
                                                            <div class="w-full">
                                                                <?php if(Auth::user()->id == $contributor->add_initiator->id): ?>
                                                                    <div class="flex text-end justify-end "> 
                                                                        <a class="flex text-xs bg-red-300 px-2 py-1 text-white rounded-md hover:bg-red-400">   
                                                                            Delete
                                                                        </a>
                                                                    </div>
                                                                <?php endif; ?>
                                                            </div>
                                                        </div>
                                                </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                    </div>
                    <!-- end of right panel //-->
            </div>
             
        </section>
        
    </div>
    
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald01fd79e7c9394df19aee57931ccf01c)): ?>
<?php $attributes = $__attributesOriginald01fd79e7c9394df19aee57931ccf01c; ?>
<?php unset($__attributesOriginald01fd79e7c9394df19aee57931ccf01c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald01fd79e7c9394df19aee57931ccf01c)): ?>
<?php $component = $__componentOriginald01fd79e7c9394df19aee57931ccf01c; ?>
<?php unset($__componentOriginald01fd79e7c9394df19aee57931ccf01c); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\goviflow\resources\views/staff/workflows/add_contributor.blade.php ENDPATH**/ ?>