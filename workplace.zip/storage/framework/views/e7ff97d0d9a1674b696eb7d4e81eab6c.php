<?php if (isset($component)) { $__componentOriginal91fdd17964e43374ae18c674f95cdaa3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal91fdd17964e43374ae18c674f95cdaa3 = $attributes; } ?>
<?php $component = App\View\Components\AdminLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AdminLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="container mx-auto mb-8">
        <!-- page header //-->
        <section class="flex flex-col w-[90%] md:w-[95%] py-8 px-4 border-red-900 mx-auto">
            
            <div class="flex border-b border-gray-300 py-2 justify-between">
                    <div >
                        <h1 class="text-2xl font-semibold font-serif text-gray-800">Assign Dean</h1>
                    </div>                
            </div>
            
        </section>
        <!-- end of page header //-->


        
        <!-- new college form //-->
        <section>
                <div>
                    <form action="<?php echo e(route('admin.deans.get_assigned_dean')); ?> " method="POST" class="flex flex-col mx-auto w-[90%] items-center justify-center">
                        <?php echo csrf_field(); ?>

                        

                        <div class="flex flex-col w-[90%] md:w-[60%] py-2 md:py-4" style="font-family:'Lato'; font-size:18px; font-weight:400;">
                            
                            Provide College Information
                        </div>


                        <?php echo $__env->make('partials._session_response', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        
                        

                         <!-- College //-->
                         <div class="flex  space-x-2 w-[90%] md:w-[60%]">
                                    <div class="flex flex-1 flex-col border-red-900  py-2">
                                            
                                            
                                        <select name="college" class="border border-1 border-gray-400 bg-gray-50
                                                                                w-full p-4 rounded-md 
                                                                                focus:outline-none
                                                                                focus:border-blue-500 
                                                                                focus:ring
                                                                                focus:ring-blue-100"
                                                                                
                                                                                
                                                                                style="font-family:'Lato';font-size:16px;font-weight:500;"
                                                                                required
                                                                                >
                                                                                <option value=''>-- Select College --</option>
                                                                                    <?php $__currentLoopData = $colleges; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $college): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                        <option class='py-4' value="<?php echo e($college->id); ?>"><?php echo e($college->college_name); ?> (<?php echo e($college->college_code); ?>)</option>
                                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                                                    
                                                                                </select>

                                                                                <?php $__errorArgs = ['college'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                                    <span class="text-red-700 text-sm">
                                                                                        <?php echo e($message); ?>

                                                                                    </span>
                                                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        
                                    </div> 

                                    <div class="flex flex-col justify-center items-center">
                                        <button type="submit" class="border border-1 bg-gray-400 py-4 px-2 text-white 
                                             hover:bg-gray-500 rounded-md text-sm md:text-lg" style="font-family:'Lato';font-weight:500;">Get College</button>
                                    </div>
                        </div>                       
                        <!-- end of College name //-->

                    </form><!-- end of new college form //-->                        
                        
                    
                <div>
        </section>
        <!-- end of new college form //-->
        

        

    </div><!-- end of container //-->
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $attributes = $__attributesOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__attributesOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $component = $__componentOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\goviflow\resources\views\admin\deans\create.blade.php ENDPATH**/ ?>