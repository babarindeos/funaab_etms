<?php if (isset($component)) { $__componentOriginal91fdd17964e43374ae18c674f95cdaa3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal91fdd17964e43374ae18c674f95cdaa3 = $attributes; } ?>
<?php $component = App\View\Components\AdminLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AdminLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="flex flex-col container mx-4 mb-8 border border-0 md:mx-auto">
        <section class="border-b border-gray-200 py-2 mt-2">
                <div class="text-2xl font-semibold ">
                    Document          
                </div>
                
        </section>

        <section class="flex flex-col md:flex-row md:space-x-4 py-8 mt-2 border-0 border-blue-900">
            <!-- left column //-->
            <div class="flex flex-col w-full md:w-3/5 space-y-4 md:space-y-8  border-0 border-green-900 ">                   
                   

               <!-- Top Panel - Document //-->                    
               <div class="flex flex-col w-full md:w-full border border-1 rounded-md py-2 px-4">
                       <div class="border-b border-1 py-2">
                               <div class="font-semibold">
                                   <?php echo e($document->title); ?>

                               </div>
                               <div class="flex flex-col md:flex-row border border-0 justify-between md:items-center ">

                                   <div class="text-xs">
                                       Submitted by <?php echo e($document->staff->surname); ?> <?php echo e($document->staff->firstname); ?> @ <?php echo e($document->created_at->format('l jS F, Y  g:i a')); ?>

                                   </div>

                                  
                                   
                               </div>
                       </div>
                       <div class="flex flex-row text-sm py-4 justify-content items-start">
                                   <div class="flex flex-col w-2/5 md:w-1/5">
                                           <a href="<?php echo e(asset('storage/'.$document->document)); ?>" target="_blank" 
                                                   class="px-6 py-6 text-center border border-1 hover:bg-blue-100 
                                                       rounded-md hover:border-blue-100 justify-center">
                                                   <div class="flex justify-center">
                                                           <?php if($document->filetype == "MS Word"): ?>
                                                           <img src="<?php echo e(asset('images/icon_doc_50.jpg')); ?>"  />
                                                           <?php elseif($document->filetype == "PDF"): ?>
                                                           <img src="<?php echo e(asset('images/icon_pdf_50.jpg')); ?>" />
                                                           <?php elseif($document->filetype == "Image | jpg"): ?>
                                                           <img src="<?php echo e(asset('images/icon_image_50.jpg')); ?>"/>
                                                           <?php endif; ?>
                                                   </div>

                                                   <div class="">
                                                           <?php echo e($document->filetype); ?>

                                                   </div>
                                                   <div class="text-xs">
                                                           <?php echo e($document->filesize); ?>

                                                   </div>
                                           </a>
                                   </div>
                                   <div class="px-4 py-2 border border-0 w-full">
                                           <?php if($document->comment==''): ?>
                                               No Comment

                                           <?php else: ?>
                                               <?php echo e($document->comment); ?>

                                           <?php endif; ?> 


                                           <!-- check if the user is the current handler //-->
                                       <?php if($current_handler == Auth::user()->id): ?>

                                           <!-- workflow start or continue //-->
                                           <div class="flex flex-col md:flex-row py-4">

                                               <!-- forward to contributor //-->
                                               <div class="flex flex-col flex-1">
                                                       <div class="font-semibold py-2">Forward to</div>

                                                       <form action="<?php echo e(route('staff.workflows.forward_document',['document'=>$document->id])); ?>" method="POST">
                                                           <?php echo csrf_field(); ?>

                                                           <!-- Contributor panel //-->
                                                           <div class="flex flex-col md:flex-row w-full border border-0">
                                                               <!-- Select List to Contributors //-->
                                                               <div class="flex flex-col border-red-900 w-[97%] md:w-[72%] py-2">                                                                            
                                                                       
                                                                       <select name="contributor" id="contributor" class="border border-1 border-gray-400 bg-gray-50
                                                                                                               w-full py-1 px-2 rounded-md 
                                                                                                               focus:outline-none
                                                                                                               focus:border-blue-500 
                                                                                                               focus:ring
                                                                                                               focus:ring-blue-100"                                                                                                                                                                                                                                                                                                                                                
                                                                                                               
                                                                                                               style="font-family:'Lato';font-size:16px;font-weight:500;"
                                                                                                               required
                                                                                                               >
                                                                                                               <option value=''>-- Select Contributor --</option>

                                                                                                               <?php $__currentLoopData = $workflow_contributors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contributor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                                                   <?php if($contributor->user_id != Auth::user()->id): ?>
                                                                                                                       <option value='<?php echo e($contributor->user_id); ?>'><?php echo e($contributor->user->staff->surname); ?> <?php echo e($contributor->user->staff->firstname); ?></option>
                                                                                                                   <?php endif; ?>
                                                                                                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                                                                                                                                       
                                                                       </select>

                                                                       <?php $__errorArgs = ['contributor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                           <span class="text-red-700 text-sm">
                                                                               <?php echo e($message); ?>

                                                                           </span>
                                                                       <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                   
                                                               </div>                                                                
                                                               <!-- end of List of Contributors //-->



                                                               <!-- Add contributor //-->
                                                               <div class="flex flex-col justify-center border border-0 md:items-center md:px-2 py-2 ">
                                                                                       
                                                                               <div>
                                                                                   <a href="<?php echo e(route('staff.workflows.add_contributor', ['document'=>$document->id])); ?>" class="border border-1
                                                                                       rounded-md py-2 px-4 text-xs text-green-500 border-green-500 hover:bg-green-500 hover:text-white font-semibold">
                                                                                       Add Contributor
                                                                                   </a>
                                                                               </div>

                                                               </div>
                                                               <!-- end of Add contributor //-->

                                       
                                                           </div>                                                            
                                                           <!-- end of contributor panel //-->




                                                               <div id='status_comment_panel' style="display:none;"><!-- group div for status and comment //-->

                                                                       <!-- Select Status //-->
                                                                       <div class="flex flex-col border-red-900 w-[97%] md:w-[95%] py-2">                                                                            
                                                                               
                                                                           <select name="status" class="border border-1 border-gray-400 bg-gray-50
                                                                                                                   w-full px-2 py-1 rounded-md 
                                                                                                                   focus:outline-none
                                                                                                                   focus:border-blue-500 
                                                                                                                   focus:ring
                                                                                                                   focus:ring-blue-100"                                                                                                                                                                                                                                                                                                                                                
                                                                                                                   
                                                                                                                   style="font-family:'Lato';font-size:16px;font-weight:500;"
                                                                                                                   required
                                                                                                                   >
                                                                                                                   <option value=''>-- Select Status --</option>
                                                                                                                   <option value='approved'>Approved </option>
                                                                                                                   <option value='unapproved'>Not Approved </option>
                                                                                                                                                                                           
                                                                           </select>

                                                                           <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                               <span class="text-red-700 text-sm">
                                                                                   <?php echo e($message); ?>

                                                                               </span>
                                                                           <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                       
                                                                       </div>                                                                
                                                                       <!-- end of Status //-->


                                                                       <!-- Comment //-->
                                                                       <div class="flex flex-col border-red-900 w-[80%] md:w-[95%] py-1">
                                                                       
                                                                           
                                                                           <textarea name="comment" class="border border-1 border-gray-400 bg-gray-50
                                                                                                                   w-full p-1 py-2 rounded-md 
                                                                                                                   focus:outline-none
                                                                                                                   focus:border-blue-500 
                                                                                                                   focus:ring
                                                                                                                   focus:ring-blue-100" 
                                                                                                                   
                                                                                                                   value="<?php echo e(old('comment')); ?>"
                                                                                                                   
                                                                                                                   style="font-family:'Lato';font-size:16px;font-weight:500;"                                                                     
                                                                                                                   maxlength="140"
                                                                                                                   >  </textarea>
                                                                                                                   <div class="text-xs text-gray-600">Comment (140 words)</div>
                                                                                                                                                                                       

                                                                                                                   <?php $__errorArgs = ['comment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                                                                       <span class="text-red-700 text-sm">
                                                                                                                           <?php echo e($message); ?>

                                                                                                                       </span>
                                                                                                                   <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                           
                                                                       </div><!-- end of comment //-->


                                                                       <!-- submit button //-->

                                                                       <button type="submit" class="border border-1 border-green-500
                                                                           bg-green-500 text-white rounded-md py-2 px-4 text-xs font-semibold mt-1">
                                                                           Send
                                                                       </button>
                                                                       <!-- end of submit button //-->

                                                                       <!-- response //-->
                                                                       <?php if(session('error')): ?>
                                                                               <?php if(session('status')=='fail'): ?>
                                                                                       <span class="flex flex-col w-[80%] md:w-[60%] py-4 px-2 my-2 bg-red-50 rounded text-red-800 font-medium" 
                                                                                           style="font-family:'Lato'; font-size:16px;"> 
                                                                                           <div class="font-semibold text-xs mb-1">[Process Error]</div>
                                                                                           <?php echo e(session('message')); ?>

                                                                                       </span>
                                                                               <?php endif; ?>
                                                                       <?php endif; ?>
                                                                       <!-- end of response //-->


                                                               </div><!-- end of group div for status and comment //-->                                                               

                                                           



                                                       </form>
                                                       <!-- end of forward button //-->



                                               </div>
                                               <!-- end of forward to contributor //-->

                                               

                                                   
                                           </div>
                                           <!-- end of  Workflow start or Continue//-->
                                       <?php endif; ?>



                                   </div>
                       </div>

               </div>
               <!-- end of Top panel -Document //-->



               <!-- Bottom panel - Workflow //-->
               <section class="border border-0 border-red-900 w-full space-x-2 py-4">
                   <div class="flex flex-col md:flex-row space-x-4">
                       <div class="w-full ">
                               <div class="border-b py-2 px-4 font-semibold text-gray-700 rounded-md">
                                   <i class="fa fa-envelope-o" aria-hidden="true"></i> Workflow Transactions (<?php echo e($workflow_transactions->count()); ?>)
                               </div>
                               <div class="px-4 py-2 space-y-4">
                                   <?php $__currentLoopData = $workflow_transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transactions): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                       <div class="rounded-md bg-gray-100 px-2 py-2">
                                               <div class="text-sm">From <span class="font-medium"><?php echo e($transactions->sender->surname); ?> <?php echo e($transactions->sender->firstname); ?></span> --&raquo; <span class="font-medium"><?php echo e($transactions->recipient->surname); ?> <?php echo e($transactions->recipient->firstname); ?></span></div>
                                               <div class="text-xs">
                                                   <?php echo e($transactions->created_at->format('l jS F, Y @ g:i a')); ?>

                                               </div>
                                               <div class="py-2">
                                                   <div>
                                                       <?php if($transactions->status=='approved'): ?>
                                                           <span class='bg-green-200 px-2 py-1 text-xs rounded-md'>
                                                               <?php echo e($transactions->status); ?>

                                                           </span>
                                                       <?php else: ?>
                                                           <span class='bg-red-200 px-2 py-1 text-xs rounded-md'>
                                                               <?php echo e($transactions->status); ?>

                                                           </span>
                                                       <?php endif; ?>
                                                       
                                                   </div>
                                                   <div class="text-sm">
                                                       <?php echo e($transactions->comment); ?>

                                                   </div>

                                               </div>

                                       </div>
                                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                               </div>
                       </div>
                   </div>
               </section>
               <!-- end of Bottom panel -->

               
            </div>
            <!-- end of left Column //-->


            <!-- Right column //-->
            <section class="flex flex-col md:w-2/5">
                    <div class="flex flex-col border border-0 w-full space-y-8">
                                <!-- right panel //-->
                                <div class="w-full  border border-1 py-4 px-4 rounded-md">
                                    <div class="flex justify-between ">
                                            <div class="font-semibold text-gray-500">
                                                Workflow Contributors
                                            </div>
                                            
                                    </div>

                                    <div class="w-full mt-2">
                                        <?php $__currentLoopData = $workflow_contributors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contributor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="w-full py-1">
                                                    <div class="flex flex-row w-full text-sm border-b ">
                                                            <div class="flex flex-col justify-center px-4 py-2 items-center">
                                                                    <?php if($contributor->user->profile!=null && $contributor->user->profile->avatar!=''): ?>
                                                                        <img class="w-12 h-10 rounded-full" src="<?php echo e(asset('storage/'.$contributor->user->profile->avatar)); ?>" />
                                                                    <?php else: ?>
                                                                        <img class="w-12" src="<?php echo e(asset('images/avatar_64.jpg')); ?>" />
                                                                    <?php endif; ?>
                                                                                                                                
                                                            </div>
                                                            <div class="flex flex-col py-2 w-full">
                                                                <a class="font-bold hover:underline" href="<?php echo e(route('admin.profile.user_profile', ['fileno'=>$contributor->user->staff->fileno])); ?>">
                                                                    <?php echo e($contributor->user->staff->surname); ?>  (<?php echo e($contributor->user->staff->firstname); ?>)
                                                                </a>
                                                                <div><?php echo e($contributor->user->staff->department->department_name); ?>  (<?php echo e($contributor->user->staff->department->department_code); ?>)</div>
                                                                <div><?php echo e($contributor->user->staff->department->ministry->name); ?> (<?php echo e($contributor->user->staff->department->ministry->code); ?>)</div>
                                                                
                                                            </div>
                                                    </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                        </div>
                        <!-- end of top panel //-->


                        <!-- bottom panel //-->
                        <section>
                                    <div class="w-full">
                                        <div class="py-2 px-4 border-b font-semibold text-gray-700 rounded-md">
                                            <i class="fa fa-envelope-o" aria-hidden="true"></i> General Messages (<?php echo e($general_messages->count()); ?>)
                                        </div>
                                        
                                        <!-- list of messages //-->
                                        <div class="flex flex-col border-0 border-blue-900 h-50 overflow-y-auto py-2 px-2 mt-2">
                                                
                                            <?php $__currentLoopData = $general_messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="flex flex-row my-2">
                                                        <div class="px-3 border-0">
                                                                <?php if($message->sender->profile!=null && $message->sender->profile->avatar!="" ): ?>
                                                                    
                                                                    <img src="<?php echo e(asset('storage/'.$message->sender->profile->avatar)); ?>" class='w-12 h-10 rounded-full' />
                                                                
                                                                <?php else: ?>
                                                                    <img class="w-12" src="<?php echo e(asset('images/avatar_64.jpg')); ?>" />  
                                                                <?php endif; ?>
                                                            
                                                        </div>
                                                        <div class="px-3 py-1 rounded-md bg-gray-100 w-full">
                                                                <a href="<?php echo e(route('admin.profile.user_profile', ['fileno'=>$message->sender->staff->fileno])); ?>"  class="font-semibold text-sm hover:underline">
                                                                        <?php echo e($message->sender->surname); ?> <?php echo e($message->sender->firstname); ?>

                                                                </a>
                                                                <div class="text-xs">
                                                                        <?php echo e($message->created_at->format('l jS F, Y @ g:i a')); ?>

                                                                </div>
                                                                <div class="text-sm py-2">
                                                                        <?php echo e($message->message); ?>

                                                                </div>

                                                        </div>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </div>
                                        <!-- end of list of messages //-->

                                </div>
                                
                        </section>
                        <!-- end of bottom panel //-->



                            </div>
                </section>
                <!--end of right column //-->


        </section>
    </div>

    

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $attributes = $__attributesOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__attributesOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $component = $__componentOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\goviflow\resources\views/admin/documents/show.blade.php ENDPATH**/ ?>