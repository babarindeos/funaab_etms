<?php if (isset($component)) { $__componentOriginal91fdd17964e43374ae18c674f95cdaa3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal91fdd17964e43374ae18c674f95cdaa3 = $attributes; } ?>
<?php $component = App\View\Components\AdminLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AdminLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="flex flex-col w-full border-1 border-0 border-blue-900 mx-auto px-2 md:px-4">
        <!-- page header //-->
        <section class="flex flex-col w-[95%] md:w-[95%] py-2 mt-6 px-0 border-0 border-red-900 mx-auto">
        
            <div class="flex border-b border-gray-300 py-2 justify-between">
                    <div >
                        <h1 class="text-2xl font-semibold font-serif text-gray-800">Circle</h1>
                    </div>
                    <div>
                            

                            <button onclick="window.history.back()" class="border border-green-600 text-green-600 py-2 px-4 
                                            text-xs md:text-sm hover:bg-green-500 hover:text-white hover:border-green-500"> &laquo; Back</button>
                    </div>
            </div>
        </section>
        <!-- end of page header //-->

        
        <section class="flex flex-col w-[95%] md:w-[95%] mx-auto">
            <div class="py-2 text-lg font-medium">
                    <?php echo e($cell->name); ?> (<?php echo e($cell->code); ?>)
            </div>
        </section>



        
                

        <section class="flex flex-col w-[95%] md:w-[95%] md:flex-row 
                        space-y-4 md:space-x-2 md:space-y-0 mx-auto border-0">

                <!-- left column //-->
                <div class="flex flex-col flex-1 px-0 border border-1 rounded-md mt-2 w-full">
                    <div class="flex flex-row justify-between border-b py-2 px-2">
                        <div class="font-semibold text-lg">
                                Users (<?php echo e($cell->users->count()); ?>)
                        </div>
                        <div>
                                <a href="#" class="underline" id="add_user_btn">
                                    Add User
                                </a>
                        </div>
                    </div>

                    <!-- add user form //-->

                    <div class="px-2">
                        <?php echo $__env->make('partials._session_response', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>

                    <div class="px-2 hidden" id="add_user_form">
                        <form action="<?php echo e(route('admin.circles.add_user', ['cell'=>$cell->id])); ?>" method="POST" class="flex flex-row space-x-1">
                            <?php echo csrf_field(); ?>

                                <!-- Staff FileNo //-->
                                <div class="flex flex-col border-red-900 py-3">
                                
                                    
                                    <input type="text" name="fileno" class="border border-1 border-gray-400 bg-gray-50
                                                                            p-1 rounded-md 
                                                                            focus:outline-none
                                                                            focus:border-blue-500 
                                                                            focus:ring
                                                                            focus:ring-blue-100 text-xs" placeholder="File No"
                                                                            
                                                                            value="<?php echo e(old('fileno')); ?>"
                                                                            
                                                                            style="font-family:'Lato';font-size:16px;font-weight:500;"                                                                     
                                                                            required
                                                                            />  
                                                                                                                                                

                                                                            <?php $__errorArgs = ['fileno'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                                <span class="text-red-700 text-sm">
                                                                                    <?php echo e($message); ?>

                                                                                </span>
                                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    
                                </div><!-- end of fileno //-->

                                <!-- Role //-->
                                <div class="flex flex-col border-red-900 py-3">
                                
                                    
                                    <input type="text" name="role" class="border border-1 border-gray-400 bg-gray-50
                                                                            p-1 rounded-md 
                                                                            focus:outline-none
                                                                            focus:border-blue-500 
                                                                            focus:ring
                                                                            focus:ring-blue-100 text-xs" placeholder="Role in Circle"
                                                                            
                                                                            value="<?php echo e(old('role')); ?>"
                                                                            
                                                                            style="font-family:'Lato';font-size:16px;font-weight:500;"                                                                     
                                                                            
                                                                            />  
                                                                                                                                                

                                                                            <?php $__errorArgs = ['role'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                                <span class="text-red-700 text-sm">
                                                                                    <?php echo e($message); ?>

                                                                                </span>
                                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    
                                </div><!-- end of role //-->


                                <div class="flex flex-col border-red-900 py-3 items-center justify-center">
                                    <button type="submit" class="border-0 bg-green-400 py-1 px-4 text-white 
                                                    hover:bg-green-500
                                                    rounded-md text-sm" style="font-family:'Lato';font-weight:500;">Add User</button>
                                </div>


                        </form>
                    </div>


                    <!-- end of add user form //-->


                    <!-- list of users //-->
                    <div class="flex flex-col px-2 py-2">
                            <?php $__currentLoopData = $cell->users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $users): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="flex flex-row py-3 space-x-2 border-b ">
                                        <div class="border-0 px-1">
                                                <?php if($users->user->profile != null): ?>
                                                <img class="w-12 h-10 rounded-full" src="<?php echo e(asset('storage/'.$users->user->profile->avatar)); ?>" />
                                                <?php else: ?>
                                                <img class="w-12 h-10" src="<?php echo e(asset('images/avatar_64.jpg')); ?>" />
                                                <?php endif; ?>
                                        </div>
                                        <div class="flex flex-col border-0 w-full px-2">
                                            <div class="font-medium">
                                                <?php echo e($users->user->staff->title); ?> 
                                                <?php echo e($users->user->staff->surname); ?> 
                                                <?php echo e($users->user->staff->firstname); ?>

                                                <?php echo e($users->user->staff->middlename); ?>

                                            </div>
                                            <div class="text-sm">
                                                <?php if($users->user->profile != null): ?>
                                                    <?php echo e($users->user->profile->designation); ?>, 
                                                <?php endif; ?>
                                                <?php echo e($users->role); ?>,
                                                (<?php echo e($users->user->staff->fileno); ?>)
                                            </div>

                                            <!-- links //-->
                                            <div class="flex flex-row border-0
                                                        justify-end space-x-2 text-sm">
                                                <div class="underline">
                                                    Permissions
                                                </div>
                                                <div class="underline">
                                                    Edit
                                                </div>
                                                <div class="underline">
                                                    Delete
                                                </div>   
                                            </div>
                                            <!-- end of links //-->
                                        </div>
                                        

                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>

                    <!-- end of list of users //-->


                </div>
                <!-- end of left column //-->


                


                <!-- right column //-->
                <div class="flex flex-col flex-1 px-0 py-2">

                    <?php if(count($circles) > 0): ?>

                            <table class="table-auto border-collapse border border-1 border-gray-200" 
                                        >
                                <thead>
                                    <tr class="bg-gray-200">
                                        <th class="text-center font-semibold py-2 w-16">SN</th>
                                        <th class="font-semibold py-2 text-left">Name</th>                                
                                        
                                        <th class="font-semibold py-2 text-center">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                        $counter = 0;
                                    ?>

                                        <?php $__currentLoopData = $circles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $circle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="border border-b border-gray-200">
                                            <td class='text-center py-4'><?php echo e(++$counter); ?>.</td>
                                            <td>
                                                <a class="hover:underline" href="<?php echo e(route('admin.circles.show', ['cell'=>$circle->id])); ?>">
                                                    <?php echo e($circle->name); ?> (<?php echo e($circle->code); ?>) - 
                                                    <small><?php echo e($circle->cell_type->name); ?></small>
                                                </a>

                                                
                                                
                                            </td>
                                            
                                            
                                            <td class="text-center">
                                                <span class="text-sm">
                                                    <a class="hover:bg-blue-500 bg-blue-400 text-white rounded-md 
                                                            px-4 py-1 text-xs" href="<?php echo e(route('admin.cells.edit', ['cell'=>$circle->id])); ?>">Edit</a>
                                                </span>
                                                <span> 
                                                    <a class="hover:bg-red-500 bg-red-400 text-white rounded-md 
                                                            px-4 py-1 text-xs" href="<?php echo e(route('admin.cells.confirm_delete', ['cell'=>$circle->id])); ?>"
                                                    >Delete</a>
                                                </span>
                                            </td>

                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    
                                    
                                    
                                </tbody>

                            </table>

                    <?php else: ?>
                        <section class="flex flex-col w-[95%] md:w-[95%] mx-auto px-0 py-8">
                                <div class="flex flex-row justify-center font-semibold text-xl text-gray-300">
                                        Currently no Circle
                                </div>
                        </section>
                    <?php endif; ?>


                </div><!-- end of right column //-->
                
                
                    


    </section>
       
        






    </div><!-- end of container //-->




 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $attributes = $__attributesOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__attributesOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $component = $__componentOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?>

<script>
$(document).ready(function(){
    $("#add_user_btn").bind('click', function(){
        $("#add_user_form").toggle();
    });
});

</script><?php /**PATH C:\xampp\htdocs\funaab\workplace\resources\views/admin/circles/show.blade.php ENDPATH**/ ?>