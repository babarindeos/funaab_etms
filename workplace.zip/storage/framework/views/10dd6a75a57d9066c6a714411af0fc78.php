<?php if (isset($component)) { $__componentOriginald01fd79e7c9394df19aee57931ccf01c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald01fd79e7c9394df19aee57931ccf01c = $attributes; } ?>
<?php $component = App\View\Components\StaffLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('staff-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\StaffLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="flex flex-col container mx-4 md:mx-auto">
        <section class="border-b border-gray-200 py-2 mt-2">
                <div class="text-2xl font-semibold ">
                    User Profile              
                </div>                
        </section>

        <?php if( $userprofile == null): ?>
            <section class="mx-auto">
                    <div class="flex flex-col justify-content items-center  py-12">
                        <div class="text-2xl text-gray-400 font-bold">Oops! An error occurred</div>
                        <div class="text-lg font-semibold">Sorry, there is no such record </div>
                    </div>
            </section>
        
        <?php elseif($userprofile->user->profile == null): ?>
            
            <section class="mx-auto">
                    <div class="flex flex-col justify-content items-center  py-12">
                        <div class="text-2xl text-gray-400 font-bold">Oops! An error occurred</div>
                        <div class="text-lg font-semibold">Sorry, the user has not created profile for the account </div>
                    </div>
            </section>
        <?php else: ?>

                <section class="flex flex-col md:flex-row rounded w-full mt-3 space-x-4">
                    <div class="flex flex-col w-full  md:w-[30%] justify-center items-center 
                                border px-8 py-4 rounded-md">
                            <div class="">
                                <?php if($userprofile->user->profile!=null && ($userprofile->user->profile->avatar != "" || $userprofile->user->profile->avatar != null)): ?>
                                    <img src="<?php echo e(asset('storage/'.$userprofile->user->profile->avatar)); ?>" class="w-36 h-36 rounded-full" />
                                <?php else: ?>
                                    <img src="<?php echo e(asset('images/avatar_150.jpg')); ?>" />
                                <?php endif; ?>
                            </div>
                            

                    </div>
                    <div class="flex flex-col justify-center md:border rounded-md md:w-[70%] py-4 px-4">
                            
                            <div class="mb-4  mx-[10%] md:mx-0 ">
                                    <div class="text-xl font-semibold">
                                            <?php echo e($userprofile->user->surname); ?> <?php echo e($userprofile->user->firstname); ?> <?php echo e($userprofile->user->middlename); ?>                                
                                    </div>
                                    <div class="text-sm">
                                            <?php echo e($userprofile->user->profile->designation); ?>, <?php echo e($userprofile->user->staff->fileno); ?>

                                    </div>                            
                            </div>


                            <div class="py-4 mx-[10%] md:mx-0">
                                    <!-- circles //-->                     
                            </div>


                            <div class="py-4 mx-[10%] md:mx-0">
                                    <div>
                                            <?php echo e($userprofile->user->email); ?>

                                    </div>
                                    <div>
                                            <?php echo e($userprofile->user->profile->phone); ?>

                                    </div>

                            </div>
                    </div>
                </section>

    <?php endif; ?>
    


    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald01fd79e7c9394df19aee57931ccf01c)): ?>
<?php $attributes = $__attributesOriginald01fd79e7c9394df19aee57931ccf01c; ?>
<?php unset($__attributesOriginald01fd79e7c9394df19aee57931ccf01c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald01fd79e7c9394df19aee57931ccf01c)): ?>
<?php $component = $__componentOriginald01fd79e7c9394df19aee57931ccf01c; ?>
<?php unset($__componentOriginald01fd79e7c9394df19aee57931ccf01c); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\funaab\workplace\resources\views/staff/profile/user_profile.blade.php ENDPATH**/ ?>