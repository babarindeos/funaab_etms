<section class="flex flex-col md:flex-row md:space-x-4">
    <a href="<?php echo e(route('staff.documents.mydocuments')); ?>" class="border border-green-600 py-2 px-4 rounded-md mt-1 font-semibold 
                hover:bg-green-600 hover:text-white hover:shadow-md">
            My Documents
    </a>

     <?php if(Auth::user()->role === 'manager'): ?>

        <div class="border border-green-600 py-2 px-4 rounded-md mt-1 font-semibold 
                        hover:bg-green-600 hover:text-white hover:shadow-md">
                Track Documents
        </div>

    <?php endif; ?>

    <a href="<?php echo e(route('staff.documents.create')); ?>" class="border border-green-600 py-2 px-4 rounded-md mt-1 font-semibold 
                     hover:bg-green-600 hover:text-white hover:shadow-md">
        Upload Document
    </a>
</section>
<?php /**PATH C:\xampp\htdocs\funaab\workplace\resources\views/partials/_document_submenu1.blade.php ENDPATH**/ ?>