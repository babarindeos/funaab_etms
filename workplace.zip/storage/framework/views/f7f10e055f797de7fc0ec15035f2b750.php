<?php if (isset($component)) { $__componentOriginal91fdd17964e43374ae18c674f95cdaa3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal91fdd17964e43374ae18c674f95cdaa3 = $attributes; } ?>
<?php $component = App\View\Components\AdminLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AdminLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="container">
        <!-- page header //-->
        <section class="flex flex-col w-[95%] md:w-[95%] py-1 mt-6 px-4 border-red-900 mx-auto">
        
            <div class="flex border-b border-gray-300 py-2 justify-between">
                    <div class="flex flex-1" >
                        <h1 class="text-2xl font-semibold font-serif text-gray-800">Documents</h1>
                    </div>
                    
                    <!-- search //-->
                    <div class="flex flex-1 justify-end border border-0">
                    
                        <input type="text" name="search" class="w-full md:w-4/5 border border-1 border-gray-400 bg-gray-50
                                    p-2 rounded-md 
                                    focus:outline-none
                                    focus:border-blue-500 
                                    focus:ring
                                    focus:ring-blue-100" placeholder="Search"                
                                
                                    style="font-family:'Lato';font-size:16px;font-weight:500;"                                                                  
                        
                        />  
                    </div>



                    <!-- end of search //-->
            </div>
        </section>
        <!-- end of page header //-->

        <?php if(count($documents)): ?>
                <section class="flex flex-col w-[95%] md:w-[95%] mx-auto px-4 py-2">
                    
                        <table class="table-auto border-collapse border border-1 border-gray-200">
                            <thead>
                                <tr class="bg-gray-200">
                                    <th width="5" class="text-center font-semibold py-2 w-16">SN</th>
                                    <th width="35%" class="font-semibold py-2 text-start">Title</th>
                                    <th width="20%" class="font-semibold py-2 text-start">File</th>
                                    <th width="20%" class="font-semibold py-2 text-start">Owner</th>                    
                                    <th width="20%" class="font-semibold py-2 text-start">Date</th>                            
                                </tr>                        
                            </thead>
                            <tbody>
                                <?php
                                    $counter = ($documents->currentPage() - 1 ) * $documents->perPage();
                                ?>

                                <?php $__currentLoopData = $documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $document): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="border border-b border-gray-200">
                                        <td class="text-center py-4"> <?php echo e(++$counter); ?>. </td>
                                        <td>
                                            <a class="hover:underline" href="<?php echo e(route('admin.documents.show', ['document'=>$document->id])); ?>">
                                                <?php echo e($document->title); ?>

                                            </a>
                                            <div>
                                                <div class="text-sm">Workflows (<?php echo e($document->workflows->count()); ?>)</div>

                                            </div>
                                        
                                        </td>
                                        <td class="text-sm">
                                            <a class="hover:underline" title="<?php echo e($document->comment); ?>" href="<?php echo e(asset('storage/'.$document->document)); ?>">
                                                <?php echo e($document->filetype); ?> (<?php echo e($document->filesize); ?>)
                                            </a>
                                        </td>
                                        <td><?php echo e($document->owner->staff->surname); ?> <?php echo e($document->owner->firstname); ?></td>
                                        <td><?php echo e($document->created_at->format('l jS F, Y')); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>

                        </table>

                        <div class="py-2">
                            <?php echo e($documents->links()); ?>

                        </div>
                    

                </section>
        <?php endif; ?>

    </div>


 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $attributes = $__attributesOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__attributesOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $component = $__componentOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\funaab\workplace\resources\views/admin/documents/index.blade.php ENDPATH**/ ?>