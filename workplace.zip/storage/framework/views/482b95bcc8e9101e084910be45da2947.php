<?php if (isset($component)) { $__componentOriginald01fd79e7c9394df19aee57931ccf01c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald01fd79e7c9394df19aee57931ccf01c = $attributes; } ?>
<?php $component = App\View\Components\StaffLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('staff-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\StaffLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="flex flex-col w-4/5 border border-1 md:w-1/3 mx-auto items-center justify-center rounded-md mt-8 mb-8 shadow-md">
        <form name="profile_create" action="<?php echo e(route('staff.profile.myprofile.update')); ?>" method="POST"  enctype="multipart/form-data" class="flex flex-col border border-1 justify-center items-center w-full">
            <?php echo csrf_field(); ?>
            <div class="flex flex-col py-2 justify-center items-center font-semibold text-xl">
                    Edit Profile
            </div>
            <div class="flex flex-row justify-center">
                    
                    <?php if(Auth::user()->profile==null): ?>
                    <img src="<?php echo e(asset('images/avatar_150.jpg')); ?>" class="w-150" />
                    <?php else: ?>
                        <img src="<?php echo e(asset('storage/'.Auth::user()->profile->avatar)); ?>" class="w-36 h-36 rounded-full" />
                    <?php endif; ?>
                    
            </div>
            
            <!-- Display name, designation and fileno //-->
            <div class="flex flex-col border-red-900 w-[80%] md:w-[60%] py-1">                             
                    <div class="mx-auto text-lg font-semibold">
                            <?php echo e(Auth::user()->staff->surname); ?> <?php echo e(Auth::user()->staff->firstname); ?> <?php echo e(Auth::user()->staff->middlename); ?>

                    </div>
                    <div class="text-sm mx-auto">
                            <?php echo e(Auth::user()->profile->designation); ?>, <?php echo e(Auth::user()->staff->fileno); ?>

                    </div>
                    
            </div>
           <!-- end of display name, designation and fileno //-->


            <!-- designation  //-->
            <div class="flex flex-col border-red-900 w-[80%] md:w-[60%] py-1">
                                    
                                    
                <input type="text" name="designation" placeholder="Designation" class="border border-1 border-gray-400 bg-gray-50
                                                        w-full p-3 rounded-md 
                                                        focus:outline-none
                                                        focus:border-blue-500 
                                                        focus:ring
                                                        focus:ring-blue-100" 
                <?php if(Auth::user()->profile !=null): ?>  value="<?php echo e(Auth::user()->profile->designation); ?> " <?php endif; ?>
                style="font-family:'Lato';font-size:16px;font-weight:500;"   
                required          
                 />
                    

                <?php $__errorArgs = ['designation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-red-700 text-sm">
                        <?php echo e($message); ?>

                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                
            </div>
            <!-- end of designation //-->


            <!-- phone  //-->
            <div class="flex flex-col border-red-900 w-[80%] md:w-[60%] py-1">
                                    
                                    
                <input type="text" name="phone" placeholder="Phone Number" class="border border-1 border-gray-400 bg-gray-50
                                                        w-full p-3 rounded-md 
                                                        focus:outline-none
                                                        focus:border-blue-500 
                                                        focus:ring
                                                        focus:ring-blue-100" 
                <?php if(Auth::user()->profile !=null): ?> value="<?php echo e(Auth::user()->profile->phone); ?>" <?php endif; ?>
                style="font-family:'Lato';font-size:16px;font-weight:500;"             
                required/>
                    

                <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-red-700 text-sm">
                        <?php echo e($message); ?>

                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                
            </div>
            <!-- end of phone //-->


            <!-- button //-->
            <div class="flex flex-row border-red-900 w-[80%] md:w-[60%] py-2 mb-2 space-x-2">
                <div class="flex flex-1 w-full border border-1">
                    <button type="submit" class="w-full border border-1 bg-gray-400 py-4 text-white 
                                hover:bg-gray-500
                                rounded-md text-md" style="font-family:'Lato';font-weight:500;">Update Profile</button>
                </div>
                
                <?php if(Auth::user()->profile !=null): ?>
                    <div class="flex border border-1">
                            <a href="<?php echo e(route('staff.profile.myprofile')); ?>" class="w-full border border-1 bg-green-400 py-4 px-4 text-white 
                                 hover:bg-green-500 rounded-md text-md" style="font-family:'Lato';font-weight:500;">Continue</a>
                    </div>
                <?php endif; ?>
            </div>



        <!-- end of buttons //-->



        </form>


    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald01fd79e7c9394df19aee57931ccf01c)): ?>
<?php $attributes = $__attributesOriginald01fd79e7c9394df19aee57931ccf01c; ?>
<?php unset($__attributesOriginald01fd79e7c9394df19aee57931ccf01c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald01fd79e7c9394df19aee57931ccf01c)): ?>
<?php $component = $__componentOriginald01fd79e7c9394df19aee57931ccf01c; ?>
<?php unset($__componentOriginald01fd79e7c9394df19aee57931ccf01c); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\goviflow\resources\views/staff/profile/edit.blade.php ENDPATH**/ ?>