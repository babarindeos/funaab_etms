<?php if (isset($component)) { $__componentOriginald01fd79e7c9394df19aee57931ccf01c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald01fd79e7c9394df19aee57931ccf01c = $attributes; } ?>
<?php $component = App\View\Components\StaffLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('staff-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\StaffLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <div class="flex flex-col container mx-4 md:mx-auto">
        <section class="border-b border-gray-200 py-2 mt-2">
                <div class="text-2xl font-semibold ">
                    My Profile              
                </div>                
        </section>

        <section class="flex flex-col md:flex-row rounded w-full mt-3 space-x-4">
            <div class="flex flex-col w-full  md:w-[30%] justify-center items-center 
                        border px-8 py-4 rounded-md">
                    <div class="">
                        <?php if(Auth::user()->profile->avatar != "" || Auth::user()->profile->avatar != null): ?>
                            <img src="<?php echo e(asset('storage/'.Auth::user()->profile->avatar)); ?>" class="w-36 h-36 rounded-full" />
                        <?php else: ?>
                            <img src="<?php echo e(asset('images/avatar_150.jpg')); ?>" />
                        <?php endif; ?>
                    </div>
                    <div class="mt-2">
                        <form enctype="multipart/form-data" action="<?php echo e(route('staff.profile.myprofile.update_avatar')); ?>"  method="POST" class="flex flex-col items-center">
                            <?php echo csrf_field(); ?>
                            <input type="file" name="photo" class="text-sm border-0 border-gray-500
                                                     items-center 
                                                     justify-center w-3/5" />
                            <?php $__errorArgs = ['photo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-red-700 text-sm mx-[10%]">
                                    <?php echo e($message); ?>

                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            

                            <div class="py-2">
                                    <button type="submit" class="px-4 py-1 text-sm 
                                                         rounded-md border border-gray-500 ring-0 
                                                         ring-cyan-500
                                                         hover:shadow-md hover:font-semibold bg-gray-100 ">Update Avatar</button>
                            </div>
                        </form>
                    </div>

            </div>
            <div class="flex flex-col justify-center md:border rounded-md md:w-[70%] py-2 px-4">
                    <div class="flex justify-end px-4 space-x-2">
                            <a href="<?php echo e(route('staff.profile.myprofile.edit')); ?>" class="border px-4 py-1 rounded-md ring-0 
                                 border-gray-500 bg-gray-100 hover:shadow-md text-xs md:text-sm hover:font-semibold">
                                Edit
                            </a>

                            <a href="<?php echo e(route('staff.profile.change_password')); ?>" class="border px-4 py-1 rounded-md ring-0 
                                 border-gray-500 bg-gray-100 hover:shadow-md text-xs md:text-sm hover:font-semibold">
                                Change Password
                            </a>
                    </div>
                    <div class="mb-4  mx-[10%] md:mx-0 ">
                            <div class="text-xl font-semibold">
                                    <?php echo e(Auth::user()->surname); ?> <?php echo e(Auth::user()->firstname); ?> <?php echo e(Auth::user()->middlename); ?>                                
                            </div>
                            <div class="text-sm">
                                    <?php echo e(Auth::user()->profile->designation); ?>, <?php echo e(Auth::user()->staff->fileno); ?>

                            </div>                            
                    </div>


                    <div class="py-4 mx-[10%] md:mx-0">
                                <div class="font-semibold py-1">
                                        Contacts
                                    </div>
                                <div>
                                        <?php echo e(Auth::user()->email); ?>

                                </div>
                                <div>
                                        <?php echo e(Auth::user()->profile->phone); ?>

                                </div>
                    </div>



                    



                    <div class="py-4 mx-[10%] md:mx-0">
                                    <!-- circles //--> 
                                    <div class="font-semibold py-1">
                                        Work Circles
                                    </div>
                                    <?php if(Auth::user()->circle->count()): ?>
                                        <?php $__currentLoopData = Auth::user()->circle; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $circle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                           <div>
                                                <?php echo e($circle->cell->name); ?> (<?php echo e($circle->cell->code); ?>)
                                           </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                       
                                    <?php else: ?>
                                        <div>
                                                Currently in no Work Circle
                                        </div>                                        
                                    <?php endif; ?>                  
                    </div>

            </div>
        </section>
    


    </div>


 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald01fd79e7c9394df19aee57931ccf01c)): ?>
<?php $attributes = $__attributesOriginald01fd79e7c9394df19aee57931ccf01c; ?>
<?php unset($__attributesOriginald01fd79e7c9394df19aee57931ccf01c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald01fd79e7c9394df19aee57931ccf01c)): ?>
<?php $component = $__componentOriginald01fd79e7c9394df19aee57931ccf01c; ?>
<?php unset($__componentOriginald01fd79e7c9394df19aee57931ccf01c); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\funaab\workplace\resources\views/staff/profile/myprofile.blade.php ENDPATH**/ ?>