<footer class="flex bottom-0 py-2 px-6 md:px-14 border border-t-1">
    <div class="text-sm">
            Federal University of Agriculture Abeokuta. Powered by ICT Resource Center. &copy;2024 All rights reserved.
    </div>
</footer><?php /**PATH C:\xampp\htdocs\funaab\workplace\resources\views/partials/_footer_fluid.blade.php ENDPATH**/ ?>