<a href="<?php echo e(route('staff.circles.general_room', ['circle'=>$circle->id])); ?>" class="hover:underline">General Room</a>
<a href="<?php echo e(route('staff.circles.announcements', ['circle'=>$circle->id])); ?>" class="hover:underline">Announcements</a>
<!--<div class="hover:underline">Projects</div> //-->
<!--<div class="hover:underline">Tasks</div> //-->
<a href="<?php echo e(route('staff.circles.team', ['circle'=>$circle->id])); ?>" class="hover:underline">Staff</a><?php /**PATH C:\xampp\htdocs\funaab\workplace\resources\views/partials/_circle_submenu.blade.php ENDPATH**/ ?>