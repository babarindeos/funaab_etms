<footer class="flex bottom-0 py-2 px-8 border border-t-1">
    <div class="text-sm">
            Ogun State Government. &copy;2024 All rights reserved.
    </div>
</footer><?php /**PATH C:\xampp\htdocs\goviflow\resources\views/partials/_footer.blade.php ENDPATH**/ ?>