<?php if (isset($component)) { $__componentOriginald01fd79e7c9394df19aee57931ccf01c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald01fd79e7c9394df19aee57931ccf01c = $attributes; } ?>
<?php $component = App\View\Components\StaffLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('staff-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\StaffLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <div class="flex flex-col container mx-4 border border-0 md:mx-auto">
        <section class="border-b border-gray-200 py-2 mt-2">
                <div class="text-2xl font-semibold ">
                    Circles               
                </div>
                
        </section>

        <!-- section //-->
        <section class="py-4 border-0">
            <div class="flex flex-col space-y-4 md:space-y-0 md:flex-row md:flex-wrap w-[100%]">
                <?php
                     $colors = ['bg-red-500', 'bg-green-500', 'bg-blue-500', 'bg-yellow-500', 'bg-purple-500', 'bg-pink-500', 'bg-orange-500', 'bg-teal-500'];

                ?>
                <?php $__currentLoopData = $circles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $circle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="flex w-full md:w-[50%] border-0">
                        <div class="flex flex-row items-center p-2">
                            <div>
                                <?php
                                    $initial = strtoupper(substr($circle->cell->name, 0, 1));
                                    $randomColor = $colors[array_rand($colors)];
                                ?>
                                <div class="flex items-center justify-center w-16 h-16 
                                            rounded-full border-0 text-2xl <?php echo e($randomColor); ?> 
                                            font-semibold text-white">
                                    <?php echo e($initial); ?>

                                </div>
                                
                            </div>
                            <div class="px-4 text-lg font-medium">
                                <a href="<?php echo e(route('staff.circles.general_room', ['circle'=>$circle->id])); ?>" class="hover:underline">
                                    <?php echo e($circle->cell->name); ?> (<?php echo e($circle->cell->code); ?>)
                                </a>
                                <div class="text-sm">
                                    <?php echo e($circle->cell->cell_type->name); ?>

                                </div>

                            </div>
                        </div>
                    </div>
                   
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

        </section>
        <!-- section //-->
    
        
    
    
        
    </div>
    


 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald01fd79e7c9394df19aee57931ccf01c)): ?>
<?php $attributes = $__attributesOriginald01fd79e7c9394df19aee57931ccf01c; ?>
<?php unset($__attributesOriginald01fd79e7c9394df19aee57931ccf01c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald01fd79e7c9394df19aee57931ccf01c)): ?>
<?php $component = $__componentOriginald01fd79e7c9394df19aee57931ccf01c; ?>
<?php unset($__componentOriginald01fd79e7c9394df19aee57931ccf01c); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\funaab\workplace\resources\views/staff/circles/index.blade.php ENDPATH**/ ?>