<?php if (isset($component)) { $__componentOriginald01fd79e7c9394df19aee57931ccf01c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald01fd79e7c9394df19aee57931ccf01c = $attributes; } ?>
<?php $component = App\View\Components\StaffLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('staff-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\StaffLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <div class="flex flex-col container mx-4 border border-0 md:mx-auto">
        <section class="border-b border-gray-200 py-2 mt-2">
                <div class="text-2xl font-semibold ">
                    My Documents               
                </div>
                
        </section>
    
        <?php echo $__env->make('partials._document_submenu1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


        <section class="flex flex-col py-1 mt-8 justif-end">
            <div class="flex justify-end border border-0">
            
                <input type="text" name="document_title" class="w-3/5 md:w-2/5 border border-1 border-gray-400 bg-gray-50
                            p-2 rounded-md 
                            focus:outline-none
                            focus:border-blue-500 
                            focus:ring
                            focus:ring-blue-100" placeholder="Search"                
                          
                            style="font-family:'Lato';font-size:16px;font-weight:500;"                                                                  
                
                />  
            </div>
             
        </section>

        <section class="flex flex-col py-2 ">
            <table class="table-auto border-collapse border border-1 border-gray-200" 
                        >
                <tr class="bg-gray-200">
                    <td class="text-center font-semibold py-2 w-16">SN</td>
                    <td class="font-semibold py-2">Documents</td>
                    <td class="font-semibold py-2">Date Created</td>
                    
                </tr>
                <tbody>
                    <?php
                        $counter = ($documents->currentPage() - 1) * $documents->perPage();
                    ?>
                    <?php $__currentLoopData = $documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $document): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="border border-b border-gray-200 ">
                            <td class='text-center py-4'><?php echo e(++$counter); ?>.</td>
                            <td class="py-2 pr-4">
                                
                                <div>
                                    <a href="<?php echo e(route('staff.documents.show', ['document'=>$document->id])); ?>" class='text-blue-500 underline font-semibold' href=''>
                                        <?php echo e($document->title); ?>

                                    </a>
                                </div>
                                <div class='flex flex-col space-y-1 md:flex-row justify-between text-xs'>
                                    <div>
                                            <div><?php echo e($document->filetype); ?> (<?php echo e($document->filesize); ?>)</div>
                                    </div>
                                    <div class="md:px-4 border border-0">
                                        <span class="px-2 py-1 rounded-md" style="background-color: #daf1e6;">
                                            <?php echo e($document->uuid); ?>

                                        </span>
                                    </div>
                                </div>
                            
                            </td>
                            <td width="20%" class="text-sm">
                                    <div class="px-0">
                                        <?php echo e($document->created_at->format('l jS F, Y @ g:i a')); ?>

                                    </div>
                            </td>
                            
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                </tbody>

            </table>

            <?php echo e($documents->links()); ?>



        </section>
        
    </div>
    
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald01fd79e7c9394df19aee57931ccf01c)): ?>
<?php $attributes = $__attributesOriginald01fd79e7c9394df19aee57931ccf01c; ?>
<?php unset($__attributesOriginald01fd79e7c9394df19aee57931ccf01c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald01fd79e7c9394df19aee57931ccf01c)): ?>
<?php $component = $__componentOriginald01fd79e7c9394df19aee57931ccf01c; ?>
<?php unset($__componentOriginald01fd79e7c9394df19aee57931ccf01c); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\goviflow\resources\views\staff\documents\my_documents.blade.php ENDPATH**/ ?>