<?php if (isset($component)) { $__componentOriginal91fdd17964e43374ae18c674f95cdaa3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal91fdd17964e43374ae18c674f95cdaa3 = $attributes; } ?>
<?php $component = App\View\Components\AdminLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AdminLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="container flex flex-col mx-auto">
        <!-- page header //-->
        <section class="flex flex-col w-[95%] md:w-[95%] py-2 mt-6 px-4 border-red-900 mx-auto">
        
            <div class="flex border-b border-gray-300 py-2 justify-between">
                    <div >
                        <h1 class="text-2xl font-semibold font-serif text-gray-800">Tracker</h1>
                    </div>
                    
            </div>
        </section>
        <!-- end of page header //-->

        <!-- Search //-->
        <Section class="border-0 border-red-600 w-1/2 mx-auto">
                <form method="GET" action="<?php echo e(route('admin.tracker.index')); ?>" class="flex flex-row border-0  border-blue-900 w-full space-x-1">
                        <div class="flex flex-1">
                                <input type="text" name="q" class="border border-1 border-gray-400 bg-gray-50
                                        w-full p-4 rounded-md 
                                        focus:outline-none
                                        focus:border-blue-500 
                                        focus:ring
                                        focus:ring-blue-100" placeholder="Track Documents..."
                                        
                                        value="<?php echo e(old('name')); ?>"
                                        
                                        style="font-family:'Lato';font-size:16px;font-weight:500;"                                                                     
                                        required
                                        />  
                                                                                                            

                                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-red-700 text-sm">
                                                <?php echo e($message); ?>

                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        </div><!-- end of search //-->
                        <!-- button //-->
                        <div>
                            <button type="submit" class="border border-1 bg-green-600 py-4 px-4 text-white 
                                     hover:bg-green-500 rounded-md text-lg" style="font-family:'Lato';font-weight:500;">Search</button>
                        </div>
                        <!-- end of button //-->
                </form>
        </Section>
        <!-- end of Search //-->


        <?php if($isPostBack): ?>
            <!-- Search Results //-->
           
            <?php if($documents->total() > 0 ): ?>
                <Section class="w-[95%] md:w-[95%] mx-auto px-4">
                    <div class="py-8">
                            <table class="table-auto border-collapse border border-1 border-gray-200">
                                <thead>
                                    <tr class="bg-gray-200">
                                        <th width="5" class="text-center font-semibold py-2 w-16">SN</th>
                                        <th width="35%" class="font-semibold py-2 text-start">Title</th>
                                        <th width="20%" class="font-semibold py-2 text-start">File</th>
                                        <th width="20%" class="font-semibold py-2 text-start">Owner</th>                    
                                        <th width="20%" class="font-semibold py-2 text-start">Date</th>                            
                                    </tr>                        
                                </thead>
                                <tbody>
                                    <?php
                                        $counter = ($documents->currentPage() - 1 ) * $documents->perPage();
                                    ?>

                                    <?php $__currentLoopData = $documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $document): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="border border-b border-gray-200">
                                            <td class="text-center py-4"> <?php echo e(++$counter); ?>. </td>
                                            <td>
                                                <a class="hover:underline" href="<?php echo e(route('admin.documents.show', ['document'=>$document->id])); ?>">
                                                    <?php echo e($document->title); ?>

                                                </a>
                                                <div>
                                                    <div class="text-sm">Workflows (<?php echo e($document->workflows->count()); ?>)</div>

                                                </div>
                                            
                                            </td>
                                            <td class="text-sm">
                                                <a class="hover:underline" title="<?php echo e($document->comment); ?>" href="<?php echo e(asset('storage/'.$document->document)); ?>">
                                                    <?php echo e($document->filetype); ?> (<?php echo e($document->filesize); ?>)
                                                </a>
                                            </td>
                                            <td><?php echo e($document->owner->staff->surname); ?> <?php echo e($document->owner->firstname); ?></td>
                                            <td><?php echo e($document->created_at->format('l jS F, Y')); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody>

                            </table>

                        <div class="py-2">
                            <?php echo e($documents->links()); ?>

                        </div>

                    </div>
                </Section>
                <!-- end of Search Results //-->
            <?php else: ?>
                <div class="mx-auto py-8 md:py-12">
                        <div class="text-lg">
                            No record is found that meets the search criteria, try again.
                        </div>
                </div>
            <?php endif; ?>
        <?php endif; ?>

    </div><!-- end of container //-->
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $attributes = $__attributesOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__attributesOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $component = $__componentOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\goviflow\resources\views/admin/tracker/index.blade.php ENDPATH**/ ?>