<?php if (isset($component)) { $__componentOriginal91fdd17964e43374ae18c674f95cdaa3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal91fdd17964e43374ae18c674f95cdaa3 = $attributes; } ?>
<?php $component = App\View\Components\AdminLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AdminLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <div class="x flex-col container mx-4 mb-8 border border-0 md:mx-auto">

        <!-- Page Header //-->
        <section class="border-b border-gray-200 py-2 mt-2">
            <div class="text-2xl font-semibold ">
                Dashboard         
            </div>            
        </section>
        <!-- end of Page Header //-->


        <!-- board //-->
        <section class="flex flex-row border border-0 py-1 mt-3">
                <div class="flex flex-col md:flex-row mx-auto md:space-x-2 w-4/5 justify-center items-center">
                    <div class="flex flex-col border border-1 border-yellow-500 
                                w-full md:w-[20%] px-4 py-4 mt-1 rounded-md bg-yellow-500">
                        <div class="text-white text-3xl">
                            <?php echo e(number_format($documents_count)); ?>

                        </div>
                        <div class="text-sm text-white font-normal">
                            Documents
                        </div>
                    </div>

                    <div class="flex flex-col border border-1 border-pink-500 
                                w-full md:w-[20%] px-4 py-4 mt-1 rounded-md bg-pink-500">
                        <div class="text-white text-3xl">
                            <?php echo e($workflows_count); ?>

                        </div>
                        <div class="text-sm text-white font-normal">
                            Workflows
                        </div>
                    </div>


                    <div class="flex flex-col border border-1 border-blue-500 
                                w-full md:w-[20%] px-4 py-4 mt-1 rounded-md bg-blue-500">
                        <div class="text-white text-3xl">
                            <?php echo e($staff_count); ?>

                        </div>
                        <div class="text-sm text-white">
                            Staff
                        </div>
                    </div>

                    <div class="flex flex-col border border-1 border-purple-500 
                                w-full md:w-[20%] px-4 py-4 mt-1 rounded-md bg-purple-500">
                        <div class="text-white text-3xl">
                            <?php echo e($departments_count); ?>

                        </div>
                        <div class="text-sm text-white">
                            Departments
                        </div>
                    </div>

                    
                </div>
        </section>
        <!-- end of board //-->


        <!-- Document Charts //-->
        <section class="flex flex-col w-full md:flex-row border-0 py-4">
                <!-- Documents by Ministries //-->
                <div class="flex-1 border-0">
                        <div class="hidden">
                            Documents By Ministries
                        </div>
                        <div>
                            <div id="ministry_document_piechart_3d" style="width: 650px; height: 400px;"></div>
                        </div>
                </div>
                <!-- end of Documents by Ministries //-->

                <!-- Documents by Departments //-->
                <div class="flex-1">
                        <div class="hidden">
                            Departments Chart
                        </div>
                        <div>
                            <div id="department_document_piechart_3d" style="width:650px; height:400px"></div>
                        </div>
                </div>
                <!-- end of Documents by Departments //-->
        </section>
        <!-- end of Document Charts //-->
        
        
        <!-- Staff Charts //-->
        <section class="flex flex-col w-full md:flex-row border-0 py-4">
                <!-- Staff by Ministries //-->
                <div class="flex-1 border-0">
                        <div class="hidden">
                            Staff By Ministries
                        </div>
                        <div>
                            <div id="ministry_staff_piechart" style="width: 650px; height: 400px;"></div>
                        </div>
                </div>
                <!-- end of Staff by Ministries //-->

                <!-- Staff by Departments //-->
                <div class="flex-1">
                        <div class="hidden">
                            Staff by Departments
                        </div>
                        <div>
                            <div id="department_staff_dotnut" style="width:650px; height:400px"></div>
                        </div>
                </div>
                <!-- end of Staff by Departments //-->
        </section>
        <!-- end of Staff Charts //-->




            
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $attributes = $__attributesOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__attributesOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $component = $__componentOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?>
<script type="text/javascript">
    // Convert PHP array to a JSON object for JavaScript
    var ministriesDocumentsChartData = <?php echo json_encode($ministries_documents_chart_data); ?>;
    var departmentsDocumentsChartData = <?php echo json_encode($departments_documents_chart_data); ?>

    var ministriesStaffChartData = <?php echo json_encode($ministries_staff_chart_data); ?>

    var departmentsStaffChartData = <?php echo json_encode($departments_staff_chart_data); ?>


    // Output the array in the console
    console.log(ministriesDocumentsChartData);
    console.log(departmentsDocumentsChartData);
    console.log(ministriesStaffChartData);
    console.log(departmentsStaffChartData);


</script> 
<script type="text/javascript">
      google.charts.load("current", {packages:["corechart"]});
      google.charts.setOnLoadCallback(drawChart);
      function drawChart() {
        
        
        /*
        var dataArray = [];
        Object.entries(ministriesDocumentsChartData).forEach(([ministry, count]) =>{
            dataArray.push([ministry, count]);
        });
        console.log(dataArray);
        */

        //--------   Ministries Documents Chart  //-----------------
        var ministries_documents_data = google.visualization.arrayToDataTable(ministriesDocumentsChartData);

        var optionsMinistryDocument = {
          title: 'Documents by Ministries',
          is3D: true,
        };

        var chart = new google.visualization.PieChart(document.getElementById('ministry_document_piechart_3d'));
        chart.draw(ministries_documents_data, optionsMinistryDocument);


        //------------ Departments Documents Chart -------------------
        var departments_documents_data = google.visualization.arrayToDataTable(departmentsDocumentsChartData);

        var optionsDepartmentDocument = {
            title: 'Documents by Departments',
            is3D: true,
        }

        var chart = new google.visualization.PieChart(document.getElementById('department_document_piechart_3d'));
        chart.draw(departments_documents_data, optionsDepartmentDocument);


        //------------- Staff Ministries Chart -------------------------
        var ministries_staff_data = google.visualization.arrayToDataTable(ministriesStaffChartData);

        var optionsMinistryStaff = {
            title: 'Staff by Ministries'
        }

        var chart = new google.visualization.PieChart(document.getElementById('ministry_staff_piechart'));
        chart.draw(ministries_staff_data, optionsMinistryStaff);


        //------------- Staff Departments Chart -------------------------
        var departments_staff_data = google.visualization.arrayToDataTable(departmentsStaffChartData);

        var optionsDepartmentStaff = {
            title: 'Staff by Departments',
            pieHole: 0.4,
        }

        var chart = new google.visualization.PieChart(document.getElementById('department_staff_dotnut'));
        chart.draw(departments_staff_data, optionsDepartmentStaff);
        

      }
</script><?php /**PATH C:\xampp\htdocs\funaab\workplace\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>