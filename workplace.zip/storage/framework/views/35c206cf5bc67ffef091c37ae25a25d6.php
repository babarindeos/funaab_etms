<?php $__env->startComponent("mail::message"); ?>
# Welcome to our Platform.

Dear <?php echo e($name); ?>,

There are a number of benefits to using our platform.


<?php echo e(url('/')); ?>

    
<?php echo $__env->renderComponent(); ?><?php /**PATH C:\xampp\htdocs\funaab\workplace\resources\views/mail/markup-mail.blade.php ENDPATH**/ ?>