<?php if (isset($component)) { $__componentOriginald01fd79e7c9394df19aee57931ccf01c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald01fd79e7c9394df19aee57931ccf01c = $attributes; } ?>
<?php $component = App\View\Components\StaffLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('staff-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\StaffLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <div class="flex flex-col container mx-4 border border-0 md:mx-auto">
        <section class="border-b border-gray-200 py-2 mt-2">
                <div class="text-2xl font-semibold ">
                    Circles               
                </div>
                
        </section>

        <!-- section //-->
        <section class="py-2 border-0">

            <!-- navigation //-->
            <div class="flex flex-col md:flex-row space-y-4 md:space-y-0 md:justify-between md:items-center border-0 ">
                    <div>
                        <div class="text-xl text-gray-800 font-semibold">
                            <?php echo e($circle->cell->name); ?> (<?php echo e($circle->cell->code); ?>)
                        </div>
                        <div class="text-gray-600 font-medium text-lg">
                            Announcements

                        </div>

                        

                    </div>
                    <div class="flex flex-row space-x-4">
                            <?php echo $__env->make('partials._circle_submenu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
            </div>
            <!-- end of navigation //-->
            
        </section>
        <!-- section //-->




        <!-- Announcement //-->
         

        <section class="py-2 mt-2">
            <div class="flex flex-col md:flex-row border-0">
                <div class="flex  flex-col md:w-[60%] border-0  py-2 overflow-y-auto h-100"><!-- left panel //-->
                

                      
                        <div class="border w-full md:w-[98%] rounded-md px-4 py-4">

                            <!-- announcement header //-->
                            <div class="flex flex-col border-b pb-4 space-y-2 md:space-y-1">
                                    <div class="py-1 font-semibold">
                                            <?php echo e($announcement->subject); ?>

                                    </div>
                                    <div class="flex flex-col md:flex-row text-sm md:space-x-6 border-0 md:items-center space-y-2 md:space-y-0">
                                            <div class="text-sm">
                                                <?php echo e($announcement->created_at->format('l jS F, Y @ g:i a')); ?>

                                            </div>
                                            <div class="flex">
                                                <div>
                                                    <?php if($announcement->sender->profile != null || $announcement->sender->profile->avatar!=""): ?> 
                                                                <img src="<?php echo e(asset('storage/'.$announcement->sender->profile->avatar)); ?>" 
                                                                        class='w-8 h-8 rounded-full hover:ring hover:ring-gray-200' />
                                                    <?php else: ?>
                                                                <img class="w-8" src="<?php echo e(asset('images/avatar_64.jpg')); ?>" /> 
                                                    <?php endif; ?>
                                                </div>
                                                <div class="flex items-center px-2">
                                                        <a class="hover:underline" href="<?php echo e(route('staff.profile.email_user_profile',['email'=>$announcement->sender->email])); ?>">
                                                                <?php
                                                                    $surname = ucfirst(strtolower($announcement->sender->surname))
                                                                ?>
                                                                <?php echo e($surname); ?> <?php echo e($announcement->sender->firstname); ?>

                                                        </a>
                                                </div>
                                            </div>
                                    </div>

                                    <!-- file Attachment //-->
                                    <?php if($announcement->file!=""): ?>
                                    <div class="text-sm">
                                            <i class="fa-solid fa-paperclip"></i> 
                                            <a href="<?php echo e(asset('storage/'.$announcement->file)); ?>" target="_blank" class="hover:underline">
                                                <span class='text-xs'> <?php echo e($announcement->filetype); ?> (<?php echo e($announcement->filesize); ?>)</span>
                                            </a>

                                    </div>
                                    <!-- end of file attachment //-->
                                    <?php endif; ?>
                                </div>
                                <!-- end of announcement header //-->



                                <!-- announcement body //-->
                                <div class="py-8">
                                    <?php echo e($announcement->message); ?>


                                </div>
                                <!-- announcement body //-->


                                <!-- announcement links //-->
                                 <div class="text-sm">
                                    <i class="fa-solid fa-globe "></i> 
                                    <a href="<?php echo e($announcement->link); ?>" class="underline text-blue-800 px-1" target="_blank">
                                        <?php echo e($announcement->link); ?>

                                    </a>

                                </div>

                                <!-- end of announcement links //-->
                                
                        </div>
                        

                        


                    
                       

                </div><!-- end of left pane //-->


                <div class="flex flex-col md:border-l  md:w-[40%] md:px-3 py-2"><!-- Right pane //-->
                    <form action="<?php echo e(route('staff.circles.store_announcement_comment',['circle'=>$circle->cell_id, 'announcement'=>$announcement->id])); ?>" method="POST">
                            <?php echo csrf_field(); ?>

                            <div class="py-1">
                                    Share your thoughts... @ <?php echo e($circle->cell->code); ?> 
                            </div>
                            <!-- textarea //-->
                            <div class="flex items-center py-1">
                                    
                                    <textarea name="message" rows="3" class="overflow-hidden border border-1 border-gray-400 bg-gray-50
                                            w-full p-2 rounded-md 
                                            focus:outline-none
                                            focus:border-blue-500 
                                            focus:ring
                                            focus:ring-blue-100" 
                                            
                                            value="<?php echo e(old('message')); ?>"
                                            required
                                            style="font-family:'Lato';font-size:16px;font-weight:500;"                                                                     
                                            maxlength="140">  </textarea>
                            </div>
                            <!-- end of textarea //-->

                            <!-- button //-->
                            <div class="flex justify-between">

                                <div class="flex text-xs text-gray-500">
                                    140 characters max
                                </div>
                                
                                <div>    
                                    <button type="submit" class="border border-1 border-green-500
                                    bg-green-500 text-white rounded-md py-2 px-4 text-xs font-semibold">
                                            Send
                                    </button>
                                </div>
                            </div>
                            <!-- end of button //-->
                    </form>



                    <!-- list of messages //-->
                    <div class="flex flex-col border-0 border-blue-900 h-50 overflow-y-auto py-2 mt-2">

                            <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="flex flex-row my-2">
                                        <div class="px-3 border-0">
                                                <?php if($message->sender->profile!=null && $message->sender->profile->avatar!="" ): ?>
                                                
                                                    <img src="<?php echo e(asset('storage/'.$message->sender->profile->avatar)); ?>" class='w-12 h-10 rounded-full' />
                                                    
                                                <?php else: ?>
                                                    <img class="w-12" src="<?php echo e(asset('images/avatar_64.jpg')); ?>" />  
                                                <?php endif; ?>
                                                
                                        </div>
                                        <div class="px-3 py-1 rounded-md bg-gray-100 w-full">
                                                <a href="<?php echo e(route('staff.profile.email_user_profile', ['email'=>$message->sender->email])); ?>" class="font-semibold text-sm hover:underline">
                                                        
                                                        <?php
                                                            $surname = ucfirst(strtolower($message->sender->surname));
                                                        ?>

                                                        <?php echo e($surname); ?> <?php echo e($message->sender->firstname); ?>

                                                </a>
                                                <div class="text-xs">
                                                        <?php echo e($message->created_at->format('l jS F, Y @ g:i a')); ?>

                                                </div>
                                                <div class="text-sm py-2">
                                                        <?php echo e($message->message); ?>

                                                </div>

                                        </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                    </div>
                    <!-- end of list of messages //-->

                    

                                                                                

                </div><!-- end of right panel //-->
            </div>             
        </section>

    
    
        





        <!-- end of announcement //-->





    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald01fd79e7c9394df19aee57931ccf01c)): ?>
<?php $attributes = $__attributesOriginald01fd79e7c9394df19aee57931ccf01c; ?>
<?php unset($__attributesOriginald01fd79e7c9394df19aee57931ccf01c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald01fd79e7c9394df19aee57931ccf01c)): ?>
<?php $component = $__componentOriginald01fd79e7c9394df19aee57931ccf01c; ?>
<?php unset($__componentOriginald01fd79e7c9394df19aee57931ccf01c); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\funaab\workplace\resources\views/staff/circles/show_announcement.blade.php ENDPATH**/ ?>