<?php if (isset($component)) { $__componentOriginal91fdd17964e43374ae18c674f95cdaa3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal91fdd17964e43374ae18c674f95cdaa3 = $attributes; } ?>
<?php $component = App\View\Components\AdminLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AdminLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="container mx-auto mb-8">
        <!-- page header //-->
        <section class="flex flex-col w-[90%] md:w-[95%] py-8 px-4 border-red-900 mx-auto">
            
            <div class="flex border-b border-gray-300 py-2 justify-between">
                    <div >
                        <h1 class="text-2xl font-semibold font-serif text-gray-800">Assign Dean</h1>
                    </div>                
            </div>
            
        </section>
        <!-- end of page header //-->


        
        

                   
           
                    <!--  Get Assigned College  //-->
                    <section>
                            <div>
                                <form action="<?php echo e(route('admin.deans.store_assign_dean')); ?> " method="POST" class="flex flex-col mx-auto w-[90%] items-center justify-center">
                                    <?php echo csrf_field(); ?>

                                    

                                       


                                        <?php echo $__env->make('partials._session_response', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                                        <!-- College //-->
                                    
                                        <div class="flex flex-1 flex-col border-red-900  w-[90%] md:w-[60%]">
                                                        <!-- College long name and code //-->                          
                                                        <div class="border border-1 border-gray-400 bg-gray-50
                                                                                                w-full p-4 rounded-md 
                                                                                                "                                                                       
                                                                                                
                                                                                                style="font-family:'Lato';font-size:16px;font-weight:500;"                                                                     
                                                                                                >          
                                                                        <?php echo e($college->college_name); ?>                        
                                                        </div><!-- end of college name and code //-->
                                                        <input type="text" name="college" value="<?php echo e($college->id); ?>" />


                                                         

                                                    <?php if($current_dean): ?>     

                                                        <div class="flex flex-col mt-6 font-semibold border-b border-gray-200 py-2" style="font-family:'Lato'; font-size:17px; ">
                                                            Current Dean Information
                                                        </div>
                                                        

                                                        <!-- Dean title, names //-->                          
                                                        <div name="start_date" class="border border-1 border-gray-400 bg-gray-50
                                                        w-full p-4 rounded-md mt-4"                                                                       
                                                        
                                                        style="font-family:'Lato';font-size:16px;font-weight:500;"                                                                     
                                                        >                                  
                                                                        <?php echo e($current_dean->staff->title); ?> <?php echo e($current_dean->staff->surname); ?> <?php echo e($current_dean->staff->firstname); ?>

                                                        </div>
                                                        <input type="text" name="current_dean_id" value="<?php echo e($current_dean->staff_id); ?>" />
                                                        <!-- end of dean title, names //-->

                                                        <!-- Start Date //-->
                                                        <div class="mt-2 py-2 font-semibold text-sm">
                                                                Start Date
                                                        </div>
                                                        <?php
                                                            $datetime = \Carbon\Carbon::parse($current_dean->start_date);
                                                        ?>
                                                                                  
                                                        <div class="border border-1 py-3 border-gray-400 bg-gray-50
                                                                                                w-full p-4 rounded-md 
                                                                                                "                                                                       
                                                                                                
                                                                                                style="font-family:'Lato';font-size:16px;font-weight:500;"                                                                     
                                                                                                >          
                                                                <?php echo e($datetime->format('l, j F Y')); ?>        
                                                        </div><!-- end of start date //-->

                                                    <!-- end date /-->
                                                    <div class="mt-2 font-semibold text-sm">
                                                        End Date
                                                    </div>
                                                    <!-- Dates //-->
                                                    <div class="flex py-2 space-x-2">     
                                                        
                                                                <!-- Day //-->
                                                                <div class="flex flex-col border-red-900 ">
                                                                    <select name="end_day" class="border border-1 border-gray-400 bg-gray-50
                                                                        w-full text-sm md:text-base py-4 md:px-8 rounded-md 
                                                                        focus:outline-none
                                                                        focus:border-blue-500 
                                                                        focus:ring
                                                                        focus:ring-blue-100"
                                                                        style="font-family:'Lato';font-size:16px;font-weight:500;"
                                                                        
                                                                    >
                                                                        <option value=''>-- Select Day --</option>
                                                                        <?php for($i= 1; $i <= 31; $i++): ?>
                                                                            <option><?php echo e($i); ?></option>
                                                                        <?php endfor; ?>                                                                 
                                                                    </select>

                                                                    <?php $__errorArgs = ['end_day'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                        <span class="text-red-700 text-sm">
                                                                            <?php echo e($message); ?>

                                                                        </span>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>                                                          
                                                                </div><!-- end of day //-->


                                                                <!-- Month //-->
                                                                <div class="flex flex-col border-red-900 ">
                                                                    <select name="end_month" class="border border-1 border-gray-400 bg-gray-50
                                                                        w-full text-sm md:text-base py-4 md:px-8 rounded-md 
                                                                        focus:outline-none
                                                                        focus:border-blue-500 
                                                                        focus:ring
                                                                        focus:ring-blue-100"
                                                                        style="font-family:'Lato';font-size:16px;font-weight:500;"
                                                                        
                                                                    >
                                                                        <option value=''>-- Select Month --</option>
                                                                        <option value='01'>January</option>
                                                                        <option value='02'>February</option>
                                                                        <option value='03'>March</option>
                                                                        <option value='04'>April</option>
                                                                        <option value='05'>May</option>
                                                                        <option value='06'>June</option>
                                                                        <option value='07'>July</option>
                                                                        <option value='08'>August</option>
                                                                        <option value='09'>September</option>
                                                                        <option value='10'>October</option>
                                                                        <option value='11'>November</option>
                                                                        <option value='12'>December</option>
                                                                                                                                  
                                                                    </select>

                                                                    <?php $__errorArgs = ['end_month'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                        <span class="text-red-700 text-sm">
                                                                            <?php echo e($message); ?>

                                                                        </span>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>                                                          
                                                                </div><!-- end of month //-->


                                                                <!-- Year //-->
                                                                <div class="flex flex-col border-red-900 ">
                                                                    <select name="end_year" class="border border-1 border-gray-400 bg-gray-50
                                                                        w-full text-sm md:text-base py-4 md:px-8 rounded-md 
                                                                        focus:outline-none
                                                                        focus:border-blue-500 
                                                                        focus:ring
                                                                        focus:ring-blue-100"
                                                                        style="font-family:'Lato';font-size:16px;font-weight:500;"
                                                                        
                                                                    >
                                                                        <option value=''>-- Select Year --</option>
                                                                        <?php for($i=2020; $i <= 2050; $i++): ?>
                                                                            <option><?php echo e($i); ?></option>
                                                                        <?php endfor; ?>
                                                                                                                                  
                                                                    </select>

                                                                    <?php $__errorArgs = ['end_year'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                        <span class="text-red-700 text-sm">
                                                                            <?php echo e($message); ?>

                                                                        </span>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>                                                          
                                                                </div><!-- end of year //-->

                                                    </div><!-- end of dates //-->
                                                    <!-- End Dates //-->
                                        <?php endif; ?>


                                        <!-- New Dean //-->


                                        <!-- end of new dean //-->
                                        <div class="flex flex-col mt-8 font-semibold border-b border-gray-200 py-2" style="font-family:'Lato'; font-size:17px; ">
                                            New Dean Information
                                        </div>

                                        <!-- Staff //-->
                                        <div class="flex flex-col border-red-900 mt-3">
                                            <select name="new_dean" class="border border-1 border-gray-400 bg-gray-50
                                                w-full text-sm md:text-base py-4 md:px-8 rounded-md 
                                                focus:outline-none
                                                focus:border-blue-500 
                                                focus:ring
                                                focus:ring-blue-100"
                                                style="font-family:'Lato';font-size:16px;font-weight:500;"
                                                
                                            >
                                                <option value=''>-- Select Staff --</option>
                                                <?php $__currentLoopData = $staff; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $st): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($st->id); ?>"><?php echo e($st->title); ?> <?php echo e($st->surname); ?> <?php echo e($st->firstname); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                                           
                                            </select>

                                            <?php $__errorArgs = ['end_day'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-red-700 text-sm">
                                                    <?php echo e($message); ?>

                                                </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>                                                          
                                        </div><!-- end of staff //-->

                                        <!-- start date /-->
                                        <div class="mt-2 font-semibold text-sm">
                                            Start Date
                                        </div>
                                        <!-- Dates //-->
                                        <div class="flex py-2 space-x-2">     
                                            
                                                    <!-- Day //-->
                                                    <div class="flex flex-col border-red-900 ">
                                                        <select name="start_day" class="border border-1 border-gray-400 bg-gray-50
                                                            w-full text-sm md:text-base py-4 md:px-8 rounded-md 
                                                            focus:outline-none
                                                            focus:border-blue-500 
                                                            focus:ring
                                                            focus:ring-blue-100"
                                                            style="font-family:'Lato';font-size:16px;font-weight:500;"
                                                            
                                                        >
                                                            <option value=''>-- Select Day --</option>
                                                            <?php for($i= 1; $i <= 31; $i++): ?>
                                                                <option><?php echo e($i); ?></option>
                                                            <?php endfor; ?>                                                                 
                                                        </select>

                                                        <?php $__errorArgs = ['start_day'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <span class="text-red-700 text-sm">
                                                                <?php echo e($message); ?>

                                                            </span>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>                                                          
                                                    </div><!-- start of day //-->


                                                    <!-- Month //-->
                                                    <div class="flex flex-col border-red-900 ">
                                                        <select name="start_month" class="border border-1 border-gray-400 bg-gray-50
                                                            w-full text-sm md:text-base py-4 md:px-8 rounded-md 
                                                            focus:outline-none
                                                            focus:border-blue-500 
                                                            focus:ring
                                                            focus:ring-blue-100"
                                                            style="font-family:'Lato';font-size:16px;font-weight:500;"
                                                            
                                                        >
                                                            <option value=''>-- Select Month --</option>
                                                            <option value='01'>January</option>
                                                            <option value='02'>February</option>
                                                            <option value='03'>March</option>
                                                            <option value='04'>April</option>
                                                            <option value='05'>May</option>
                                                            <option value='06'>June</option>
                                                            <option value='07'>July</option>
                                                            <option value='08'>August</option>
                                                            <option value='09'>September</option>
                                                            <option value='10'>October</option>
                                                            <option value='11'>November</option>
                                                            <option value='12'>December</option>
                                                                                                                      
                                                        </select>

                                                        <?php $__errorArgs = ['start_month'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <span class="text-red-700 text-sm">
                                                                <?php echo e($message); ?>

                                                            </span>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>                                                          
                                                    </div><!-- start of month //-->


                                                    <!-- Year //-->
                                                    <div class="flex flex-col border-red-900 ">
                                                        <select name="start_year" class="border border-1 border-gray-400 bg-gray-50
                                                            w-full text-sm md:text-base py-4 md:px-8 rounded-md 
                                                            focus:outline-none
                                                            focus:border-blue-500 
                                                            focus:ring
                                                            focus:ring-blue-100"
                                                            style="font-family:'Lato';font-size:16px;font-weight:500;"
                                                            
                                                        >
                                                            <option value=''>-- Select Year --</option>
                                                            <?php for($i=2020; $i <= 2050; $i++): ?>
                                                                <option><?php echo e($i); ?></option>
                                                            <?php endfor; ?>
                                                                                                                      
                                                        </select>

                                                        <?php $__errorArgs = ['start_year'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <span class="text-red-700 text-sm">
                                                                <?php echo e($message); ?>

                                                            </span>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>                                                          
                                                    </div><!-- start of year //-->

                                        </div><!-- end of dates //-->
                                        <!-- Start Dates //-->

                                        <div class="flex flex-col border-red-900 w-[100%] md:w-[100%] mt-4">
                                            <button type="submit" class="border border-1 bg-gray-400 py-4 text-white 
                                                           hover:bg-gray-500
                                                           rounded-md text-lg" style="font-family:'Lato';font-weight:500;">Assign Dean</button>
                                        </div>
                                
                                </form>                    

                            </div>
                    </section>
                    <!--  End of Assigned Dean//-->
                    
                
            
       


    </div><!-- end of container //-->
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $attributes = $__attributesOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__attributesOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $component = $__componentOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\goviflow\resources\views\admin\deans\assign_dean.blade.php ENDPATH**/ ?>